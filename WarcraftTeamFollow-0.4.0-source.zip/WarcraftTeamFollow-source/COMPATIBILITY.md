# Live compatibility investigation — 27 October 2026

## Correction and working replacement

Further inspection found a separate **BlizzardBrowser.exe** process with Chromium, serving the real menu from the game's loopback HTTP service. The earlier inference that the WebUI was absent was incorrect; checking modules in the main game process was insufficient. The root HTTP path was also misleading: `/webui/index.html` and `/webui/GlueManager.js` returned the current build's real files.

Read-only discovery of the game's own local menu session then allowed a successful websocket connection. `TeamGetInfo` returned a real `TeamsInformation.payload.message.partyMembers` roster. `FriendsGetFriends` returned real friend-presence snapshots. The current menu code uses `currentGameState = open` and `JoinFriendGameLobby { auroraId }` for joining friends. It leaves the matchmaking team before joining, so the companion remembers the roster when armed.

Prototype 0.2 uses this direct local connection and a separate local page. Its live team/friend monitoring and reconnect have been verified on 3.0.1.24371. The successful join itself remains to be tested with a friend, as the user chose to do that later. Twenty-eight behavior tests and seven local HTTP checks pass. No game files or registry changes are required.

During investigation, a combined `SendGameLobbySetup` / `GetGameInfo` probe caused the game to close while in menus. The exact offending query was not isolated by repeating it. Both were removed and explicitly excluded from the companion's command allowlist. The game was restarted through Battle.net, and read-only polling of the two proven queries reconnected successfully.

The original file-based loader failure is still real, but it no longer blocks this replacement. The original observations below are retained as investigation history and must be read with these corrections.

## Result

The first WebUI-based prototype does not load in the installed Warcraft III 3.0.1.24371. The previous installation-success report meant that files were copied and the local-files setting changed; it did not establish runtime compatibility. Do not ask the user to keep restarting this build to find the panel.

## Locally verified evidence

- The running executable is `D:\BattleNet\Warcraft III\_retail_\x86_64\Warcraft III.exe`, version 3.0.1.24371.
- The expected `webui/index.html` and `webui/follow-friend.js` overrides existed, and the actual user's `Allow Local Files` value was 1.
- The panel was absent in live captures of the main menu, multiplayer menu and Custom Games browser.
- No Chromium/CEF/browser menu component appeared in the running game's loaded module list.
- Loopback listener ports appeared after entering multiplayer. This alone does not identify a usable WebUI service. Root HTTP probes did not return a recognizable menu document. No claim that every possible local interface has been ruled out is warranted.
- The old public W3Champions launcher repo is not evidence of the current launcher's implementation. The current `launcher-e-release` repository contains release artifacts rather than the new integration source.

## Next development work

Establish an integration with the current build before adding features or re-enabling installation. Possible investigations are a current local client interface or an external desktop companion using the visible friends/join controls. Neither replacement is implemented or verified yet. The existing matching state machine and tests can be reused once a real adapter is available.

Do not scan for account credentials or log session connection credentials. Any future local client adapter must keep session identifiers local and out of diagnostic exports. Never infer native UI compatibility from simulated event tests.

## Verification available now

The matching state machine passes 12 simulated tests. The installer supports restoration of its two owned files and the prior local-files setting. The installer now rejects the locally verified incompatible build before making any new installation changes. These checks do not establish working automatic joining.
