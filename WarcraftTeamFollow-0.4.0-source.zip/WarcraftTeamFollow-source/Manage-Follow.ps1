[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [ValidateSet('Install', 'Uninstall', 'Status')][string]$Action = 'Status',
    [string]$GamePath = 'D:\BattleNet\Warcraft III'
)
$ErrorActionPreference = 'Stop'
$gameRoot = (Resolve-Path -LiteralPath $GamePath).Path
$retailRoot = Join-Path $gameRoot '_retail_'
$executable = Join-Path $retailRoot 'x86_64\Warcraft III.exe'
if (-not (Test-Path -LiteralPath $executable -PathType Leaf)) { throw 'Warcraft III was not found at this location.' }
$webRoot = Join-Path $retailRoot 'webui'
$backupRoot = Join-Path $webRoot '.warcraft-follow-backup'
$manifestPath = Join-Path $backupRoot 'manifest.json'
$indexPath = Join-Path $webRoot 'index.html'
$scriptPath = Join-Path $webRoot 'follow-friend.js'
$registryPath = 'HKCU:\Software\Blizzard Entertainment\Warcraft III'
$registryName = 'Allow Local Files'
$version = (Get-Item -LiteralPath $executable).VersionInfo.FileVersion
$knownIncompatible = $version -eq '3.0.1.24371'

function Get-FileHashOrNull([string]$Path) {
    if (Test-Path -LiteralPath $Path -PathType Leaf) { return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash }
    return $null
}
function Restore-Installation($Saved) {
    foreach ($entry in $Saved.files) {
        $destination = Join-Path $webRoot $entry.name
        if ($entry.existed) {
            Copy-Item -LiteralPath (Join-Path $backupRoot $entry.name) -Destination $destination -Force
        } elseif (Test-Path -LiteralPath $destination) {
            Remove-Item -LiteralPath $destination
        }
    }
    if ($Saved.registry.valueExisted) {
        New-ItemProperty -LiteralPath $registryPath -Name $registryName -Value $Saved.registry.value -PropertyType $Saved.registry.kind -Force | Out-Null
    } elseif (Test-Path -LiteralPath $registryPath) {
        Remove-ItemProperty -LiteralPath $registryPath -Name $registryName -ErrorAction SilentlyContinue
    }
}

if ($Action -eq 'Status') {
    [pscustomobject]@{
        GameVersion = $version
        Installed = (Test-Path -LiteralPath $manifestPath)
        Compatibility = $(if ($knownIncompatible) { 'Legacy file-based install failed; use the Team Follow companion instead' } else { 'Unverified' })
        MenuOverride = (Test-Path -LiteralPath $indexPath)
        LocalFilesEnabled = ((Get-ItemProperty -LiteralPath $registryPath -Name $registryName -ErrorAction SilentlyContinue).$registryName -eq 1)
        GameRunning = [bool](Get-Process -Name 'Warcraft III' -ErrorAction SilentlyContinue)
    } | Format-List
    return
}
# The original file-based installation failed its live check on this build.
# Removing its inactive overrides needs no restart and does not touch packed assets.
if ((Get-Process -Name 'Warcraft III' -ErrorAction SilentlyContinue) -and
    -not ($Action -eq 'Uninstall' -and $knownIncompatible)) {
    throw 'Close Warcraft III before installing or removing Follow.'
}
if ($Action -eq 'Uninstall') {
    if (-not (Test-Path -LiteralPath $manifestPath)) { throw 'No Follow installation record was found.' }
    $saved = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
    $names = @($saved.files | ForEach-Object { $_.name })
    if ($saved.format -ne 1 -or $names.Count -ne 2 -or
        @($names | Where-Object { $_ -notin @('index.html', 'follow-friend.js') }).Count -gt 0 -or
        @($names | Select-Object -Unique).Count -ne 2) {
        throw 'The installation record is not recognized. No files were changed.'
    }
    foreach ($entry in $saved.files) {
        $currentHash = Get-FileHashOrNull (Join-Path $webRoot $entry.name)
        if ($currentHash -and $currentHash -ne $entry.installedHash) {
            throw ('The file ' + $entry.name + ' changed after installation. Removal stopped to preserve your changes. Backup: ' + $backupRoot)
        }
        if ($entry.existed -and -not (Test-Path -LiteralPath (Join-Path $backupRoot $entry.name))) {
            throw ('A required backup is missing: ' + $entry.name)
        }
    }
    if (-not $PSCmdlet.ShouldProcess($gameRoot, 'Remove Follow and restore previous files and local-files setting')) { return }
    Restore-Installation $saved
    foreach ($entry in $saved.files) {
        $backupFile = Join-Path $backupRoot $entry.name
        if (Test-Path -LiteralPath $backupFile) { Remove-Item -LiteralPath $backupFile }
    }
    Remove-Item -LiteralPath $manifestPath
    if (@(Get-ChildItem -LiteralPath $backupRoot -Force).Count -eq 0) { Remove-Item -LiteralPath $backupRoot }
    if (-not $saved.webRootExisted -and @(Get-ChildItem -LiteralPath $webRoot -Force).Count -eq 0) { Remove-Item -LiteralPath $webRoot }
    Write-Output 'Follow removed. Previous menu files and the local-files setting have been restored.'
    return
}

if ($knownIncompatible) {
    throw ('The original file-based install failed on Warcraft III ' + $version + '. Use Start Team Follow.cmd for the replacement companion. No game-file installation is required.')
}
if (Test-Path -LiteralPath $backupRoot) { throw 'An installation or backup already exists. Remove or recover it before reinstalling.' }
$sourceScript = Join-Path $PSScriptRoot 'webui\follow-friend.js'
if (-not (Test-Path -LiteralPath $sourceScript)) { throw 'The Follow script is missing from the package.' }
$indexContent = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'webui\index.html') -Raw
if (Test-Path -LiteralPath $indexPath) {
    $original = Get-Content -LiteralPath $indexPath -Raw
    if ($original -match 'follow-friend\.js') { throw 'The menu already references Follow. Check the existing installation.' }
    $glue = [regex]::new('<script\b[^>]*\bsrc\s*=\s*["''][^"'']*GlueManager\.js[^"'']*["''][^>]*>', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if ($glue.Matches($original).Count -ne 1) { throw 'The existing menu has an unfamiliar structure. No files were changed.' }
    $indexContent = $glue.Replace($original, '<script src="follow-friend.js"></script>' + [Environment]::NewLine + '$0', 1)
}
$regKey = Get-Item -LiteralPath $registryPath -ErrorAction SilentlyContinue
$valueExisted = $regKey -and ($regKey.GetValueNames() -contains $registryName)
$saved = [ordered]@{
    format = 1
    gameVersion = $version
    webRootExisted = [bool](Test-Path -LiteralPath $webRoot)
    registry = [ordered]@{
        valueExisted = [bool]$valueExisted
        value = $(if ($valueExisted) { $regKey.GetValue($registryName) } else { $null })
        kind = $(if ($valueExisted) { $regKey.GetValueKind($registryName).ToString() } else { $null })
    }
    files = @('index.html', 'follow-friend.js') | ForEach-Object {
        [pscustomobject]@{ name = $_; existed = [bool](Test-Path -LiteralPath (Join-Path $webRoot $_)); installedHash = $null }
    }
}
if (-not $PSCmdlet.ShouldProcess($gameRoot, 'Install Follow menu prototype and enable local menu files')) { return }
New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
foreach ($entry in $saved.files) {
    if ($entry.existed) { Copy-Item -LiteralPath (Join-Path $webRoot $entry.name) -Destination (Join-Path $backupRoot $entry.name) }
}
# Save recovery information before changing the active files.
$saved | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $manifestPath -Encoding UTF8
try {
    [System.IO.File]::WriteAllText($indexPath, $indexContent, [System.Text.UTF8Encoding]::new($false))
    Copy-Item -LiteralPath $sourceScript -Destination $scriptPath -Force
    if (-not (Test-Path -LiteralPath $registryPath)) { New-Item -Path $registryPath -Force | Out-Null }
    New-ItemProperty -LiteralPath $registryPath -Name $registryName -Value 1 -PropertyType DWord -Force | Out-Null
    foreach ($entry in $saved.files) { $entry.installedHash = Get-FileHashOrNull (Join-Path $webRoot $entry.name) }
    $saved | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $manifestPath -Encoding UTF8
} catch {
    $installError = $_
    Restore-Installation $saved
    throw ('Installation failed and previous files were restored. Recovery record retained at ' + $backupRoot + '. Error: ' + $installError.Exception.Message)
}
Write-Output ('Follow installed for Warcraft III ' + $version + '. Start normally through Battle.net. Diagnostics mode is on by default.')
