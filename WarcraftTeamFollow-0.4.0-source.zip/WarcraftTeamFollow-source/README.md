# Warcraft Team Follow — desktop companion 0.4

## Windows executable

Download or share `releases/WarcraftTeamFollow-0.4.0-win-x64/WarcraftTeamFollow.exe`, or the ZIP beside that folder. Double-click the EXE to open the native desktop interface. No installer, separate Node.js installation, or PowerShell 7 installation is needed. Requires Windows 10/11 x64 with .NET Framework 4.8. The executable is unsigned.

Start Warcraft III normally, then open the companion. Add your friends' full BattleTags or select your current team. Diagnostics starts on: turn it off and enable watching when ready to join. Following stays enabled across joins and pauses while you are in a lobby or match. It starts off each time you reopen the app. Minimize the window to keep it running; close it to stop the helper.

The desktop version saves each person's friends under `%LOCALAPPDATA%\WarcraftTeamFollow\settings\friends.json`. The shared EXE contains no saved friends, game-session details, or personal settings. The app extracts its bundled files into the same local application-data folder. Everyone uses their own Battle.net account and must already be friends with the people they follow.

The packaged EXE passed startup, save/restore, diagnostics-privacy, and bundled-runtime checks. Its compiled game discovery connected to the running Warcraft III 3.0.1.24371 client and read the live friend roster. See `desktop/README.md` for rebuilding. The web-interface instructions below describe the development version.

The companion connects directly to the running Warcraft III menu service. It can read the current team automatically, follow manually added friend BattleTags, or combine both. No game-file installation is required.

**Verified locally:** a real automatic join into a friend's open custom lobby on Warcraft III 3.0.1.24371, real team and friend snapshots, reconnection after restarting the game, saved friends, and 48 local behavior/persistence tests plus 8 local HTTP interface checks. Continuous pause/resume across an entire match is covered by local event tests; a complete live match-cycle test remains to be done.

**Live-tested path:** enable Follow while in **Custom Games**. On 27 October 2026 the helper requested to join a friend, entered the open lobby, and confirmed the local player's occupied roster slot. Team-based selection and actual password-protected joins still need their own live tests. Diagnostics mode is on by default. No claim of Blizzard approval is made.

## Open the helper

Double-click **Start Team Follow.cmd** in this folder. It starts the local helper and opens its page in your browser. Node.js 22+ and PowerShell 7 must be installed; this computer already has them.

A running helper is also available at the local address written into `runtime/companion.json`. The address can change when the helper restarts. The helper runs only on 127.0.0.1 and does not expose a service to your local network or the internet.

## First friend test

Use **Include my current team** to capture team members automatically. To follow a specific friend without a team, enter their full BattleTag under **Add a friend's BattleTag**, click **Add**, and uncheck **Include my current team** if desired. You can also combine both sources. Manually added players must already be Battle.net friends; adding a tag here does not send a friend request. Remove a tag with its × button. Every addition, removal and team-selection change is saved automatically on this PC in `settings/friends.json` and restored after helper or PC restarts. Add your usual friends once. Only BattleTags and the team checkbox are saved; following always starts off and diagnostics starts on.

All controls are in the companion's web page, not inside Warcraft III. After choosing players and enabling watching, return to the game. The background helper reads activity and, in live mode, requests the join automatically. The page does not need to stay visible, but the helper and game must keep running. Follow now stays enabled across joins, lobbies and matches, pausing joining until you return to Custom Games. Leave diagnostics on for the first test.

1. Start Warcraft III normally through Battle.net.
2. Form a team with your friend using the game's team controls. Both of you must be Battle.net friends so the game's friend presence and Join Friend feature are available.
3. In the companion, verify the names under **Your current team**.
4. Open **Custom Games** and check the menu acknowledgement. Stay outside a lobby, match, or queue.
5. Leave **Diagnostics only** checked and click **Watch selected players**.
6. Have a team member host or join a custom lobby. Their activity should change to **Lobby is joinable**, and the helper should report **Ready to follow**. Diagnostics mode sends no join or team-leaving command.
7. To try a real join, turn diagnostics off, verify you are still in the menus, and click **Watch selected players** again. The helper waits for fresh friend activity, then requests to join the first available remembered player.

Changing diagnostics mode stops following; enable it again to use the selected mode.

## How the team is used

Enabling Follow remembers the selected non-self team members and manually added friends, removing duplicates. It keeps that group even if a friend leaves the matchmaking team to enter a custom lobby. Click **Watch selected players** again to refresh the remembered group. There is no automatic following of strangers or players added after you captured the selection. Changing a tag, the team selection, or diagnostics mode stops following until you enable it again.

The game itself leaves its matchmaking team when using Join Friend. The companion follows the same native sequence: cancel outstanding team invitations, leave the current team if necessary, then request `JoinFriendGameLobby` using the friend's native account identifier. The helper does not send invitations, whispers, or chat messages.

Live mode keeps **Follow on until you stop it**. It pauses joining while you are already in a lobby, loading, playing or queuing. After leaving, it waits for a recognized menu return or the game's Custom Games list, then fetches fresh friend activity before resuming. Leaving/loading signals alone cannot authorize a new join during a match transition.

Each observed friend lobby is attempted once, with at least ten seconds between different attempts. The helper recognizes a new lobby when its name changes or the friend's activity closes and reopens. Leaving a lobby does not immediately pull you back into the same one. If a friend recreates the same name so quickly that no presence transition is observed, use **Refresh selected players** once to allow another attempt. The remembered selection is preserved during a match; manually stopping or changing the selection/diagnostics disables Follow. A helper restart, sign-out or game connection loss still starts it off.

If the game returns its intermediate lobby/password confirmation, the helper completes that same attempt once with an empty password, using the native menu's confirmation command. If the request repeats, a password field appears. Passwords are used for that submission only and are never saved or included in reports. An unsolicited or differently named lobby confirmation cannot trigger a join.

The helper never switches away from an existing lobby or match, retries a failed lobby endlessly, or re-enables itself after reconnecting. A matching named lobby containing the local player's occupied slot confirms a join; incomplete lobby callbacks do not. The successful open-lobby live test did not emit a password callback, so the new confirmation handling remains verified by simulated tests rather than that live attempt.

## Limits and troubleshooting

- If only you appear, invite a friend to the team in Warcraft III. The helper cannot create a team for you.
- If **Waiting for game** appears, start the game and wait. Discovery retries automatically. Multiple game clients are deliberately rejected.
- A teammate who is not on your Battle.net friends list may have no readable presence and will not be automatically joined.
- A friend is eligible only with fresh online Warcraft III presence and the game's explicit `currentGameState = open` flag. No lobby name is required. The game may still reject full, private, password-protected, started, or inaccessible lobbies.
- The menu acknowledgement matters: a companion attached after a match has already begun might not have received earlier game-state events. Only enable Follow while you are actually in Custom Games. When it observes lobby/gameplay/queue transitions, it pauses joining while keeping Follow enabled. If it cannot confirm a safe menu return, it waits; open Custom Games to provide a fresh game-list event.
- A future game build is monitored, but live following is blocked until its behavior is verified.
- Use **Recent activity & diagnostics → Show diagnostic report** for a report that excludes names and session identifiers.

The helper starts in diagnostics mode. Live auto-joining from Custom Games has now succeeded in the real game. Earlier attempts produced `RequestForPassword` events even though the user reported an open lobby; the old helper ignored them and showed a generic timeout. The corrected helper handles that response and explains any remaining password requirement instead of timing out silently.

## Stop or remove

Click **Stop following** to stop new join attempts. Click **Quit helper** to stop the local companion. Closing the page alone does not stop the background helper.

You can also run `Stop-TeamFollow.ps1` from this folder to stop the helper without its page.

To remove the companion, quit it and remove this project folder. It makes no game-folder or registry changes. The previous file-based prototype has already been removed and its original local-files setting restored.

## Implementation and verification

`companion/team-follow.cjs` contains the team/presence state machine. `companion/server.cjs` serves the local page and manages the game connection. `companion/Get-MenuConnection.ps1` and `MenuDiscovery.cs` locate the game's loopback menu service and its current session through read-only inspection of the Warcraft III process. No memory is modified, no code is injected, and no account credentials are searched for.

The local menu session is held in memory and passed through a private child-process pipe. It is never included in the page, browser address, runtime record, logs, or exported diagnostics. The page's separate request token protects local control actions. Host validation, same-origin checks, no CORS access, and an explicit game-command allowlist are included.

Only `TeamGetInfo` and `FriendsGetFriends` are used for background polling. Two additional state queries tried during development caused the game to close; both were removed and are absent from the production command allowlist. The game was restarted normally afterward, and the companion reconnected successfully using the tested queries.

The original WebUI installer remains for historical development work and is blocked on this build because its file-loading approach did not work. Its failure did not mean the game's WebUI or local socket had been removed: later inspection found them in a separate BlizzardBrowser process.

Run the local behavior tests with:

```powershell
node --test tests/*.test.cjs
```

With the helper running, verify its HTTP interface without enabling Follow:

```powershell
node tests/http-smoke.cjs
```

The `research/live-*` files came from this user's installed game for local analysis. They are excluded from Git and are not redistributable assets. Do not ship them with a release.
