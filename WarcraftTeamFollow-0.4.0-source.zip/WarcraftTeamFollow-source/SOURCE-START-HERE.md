# Source package — Warcraft Team Follow 0.4.0

This archive contains the editable desktop interface, launcher, game discovery,
JavaScript companion and web interface, tests, and build scripts. The webui/
folder and Manage-Follow.ps1 belong to an older, unsupported in-game prototype;
use the desktop companion for the verified build.

Start with desktop/README.md for build and test instructions.

To build the Windows executable:
1. Extract the entire folder to a writable location on Windows 10/11 x64.
2. Install Node.js v24.15.0 x64 (the included Node license matches that version).
3. Ensure .NET Framework 4.8 is available, including its C# compiler.
4. Open PowerShell in the extracted project folder and run:
   .\desktop\Build-Windows.ps1
5. Find the executable and sharing ZIP in releases/.

To run behavior tests:
   node --test tests/*.test.cjs

Edit desktop/DesktopApp.cs to change the native interface.
Edit companion/team-follow.cjs to change follow behavior.
Edit companion/server.cjs to change the game connection and local API.

No saved friends, local runtime records, screenshots, game captures, compiled
executables, or Node.js binaries are included. The build creates those outputs.
Each user adds their own friends in the app. Following starts off.

This is unofficial source code. Full live match-cycle, team selection, and
password-protected lobby tests remain pending; see the project README.
