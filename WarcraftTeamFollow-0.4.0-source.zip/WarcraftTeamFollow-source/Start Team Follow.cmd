@echo off
pwsh.exe -NoProfile -File "%~dp0Start-TeamFollow.ps1"
if errorlevel 1 pause
