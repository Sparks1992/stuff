[CmdletBinding()]
param([switch]$NoBrowser,[switch]$Foreground)
$ErrorActionPreference='Stop'
$server=Join-Path $PSScriptRoot 'companion\server.cjs'
$recordPath=Join-Path $PSScriptRoot 'runtime\companion.json'
$node=(Get-Command node.exe -ErrorAction Stop).Source
if($Foreground){ & $node $server; return }
$url=$null
if(Test-Path -LiteralPath $recordPath){
    try{
        $record=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json
        $uri=[Uri]$record.url
        if($uri.Scheme -eq 'http' -and $uri.Host -eq '127.0.0.1'){
            $response=Invoke-RestMethod -Uri ($record.url+'/api/diagnostics') -TimeoutSec 2
            if($null -ne $response.connected){$url=$record.url}
        }
    }catch{}
}
if(-not $url){
    Start-Process -FilePath $node -ArgumentList ('"'+$server+'"') -WorkingDirectory $PSScriptRoot -WindowStyle Hidden | Out-Null
    for($attempt=0;$attempt -lt 30;$attempt++){
        Start-Sleep -Milliseconds 200
        if(Test-Path -LiteralPath $recordPath){
            try{
                $record=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json
                $uri=[Uri]$record.url
                if($uri.Scheme -eq 'http' -and $uri.Host -eq '127.0.0.1'){
                    $response=Invoke-RestMethod -Uri ($record.url+'/api/diagnostics') -TimeoutSec 1
                    if($null -ne $response.connected){$url=$record.url;break}
                }
            }catch{}
        }
    }
}
if(-not $url){throw 'The Team Follow helper did not start.'}
if(-not $NoBrowser){Start-Process $url}
Write-Output ('Team Follow is available at '+$url)
