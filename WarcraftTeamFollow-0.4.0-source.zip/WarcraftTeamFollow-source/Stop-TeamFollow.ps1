$ErrorActionPreference='Stop'
$recordPath=Join-Path $PSScriptRoot 'runtime\companion.json'
if(-not(Test-Path -LiteralPath $recordPath)){Write-Output 'Team Follow is not running.';return}
$record=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json
$uri=[Uri]$record.url
if($uri.Scheme -ne 'http' -or $uri.Host -ne '127.0.0.1'){throw 'Unrecognized companion address.'}
$page=Invoke-WebRequest -Uri $record.url -TimeoutSec 3
$html=if($page.Content -is [byte[]]){[Text.Encoding]::UTF8.GetString($page.Content)}else{[string]$page.Content}
$match=[regex]::Match($html,'name="wf-token" content="([a-f0-9]{48})"')
if(-not $match.Success){throw 'The local companion did not provide its control token.'}
Invoke-RestMethod -Uri ($record.url+'/api/stop') -Method Post -Headers @{'X-WF-Token'=$match.Groups[1].Value} -TimeoutSec 3 | Out-Null
Write-Output 'Team Follow stopped.'
