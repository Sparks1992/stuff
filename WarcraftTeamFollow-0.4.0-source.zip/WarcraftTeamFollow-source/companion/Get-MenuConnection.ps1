$ErrorActionPreference = 'Stop'
$clients = @(Get-Process -Name 'Warcraft III' -ErrorAction SilentlyContinue)
if ($clients.Count -ne 1) { throw 'Exactly one Warcraft III client must be running.' }
$client = $clients[0]
$ports = @(Get-NetTCPConnection -OwningProcess $client.Id -State Listen -ErrorAction SilentlyContinue | Where-Object { $_.LocalAddress -eq '127.0.0.1' } | Sort-Object LocalPort | Select-Object -ExpandProperty LocalPort)
$menuPort = $null
foreach ($port in $ports) {
    try {
        $response = Invoke-WebRequest -Uri ('http://127.0.0.1:' + $port + '/webui/index.html') -TimeoutSec 2
        $html = if ($response.Content -is [byte[]]) { [Text.Encoding]::UTF8.GetString($response.Content) } else { [string]$response.Content }
        if ($html -match 'GlueManager') { $menuPort = $port; break }
    } catch { }
}
if (-not $menuPort) { throw 'Open the Warcraft III menus and wait for the local menu service.' }
Add-Type -Path (Join-Path $PSScriptRoot 'MenuDiscovery.cs')
$session = [WarcraftMenuDiscovery]::FindLocalMenuSession($client.Id)
if (-not $session) { throw 'The local menu session is not available.' }
# This JSON is a private pipe to the companion process. Never copy it to logs or reports.
@{port=$menuPort;session=$session;version=$client.MainModule.FileVersionInfo.FileVersion;pid=$client.Id} | ConvertTo-Json -Compress
