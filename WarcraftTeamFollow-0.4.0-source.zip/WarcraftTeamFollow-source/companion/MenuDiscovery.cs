using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

// Locates only Warcraft III's local menu URL, never account authentication data.
// Read-only: no memory writes, injection, remote threads, or saved session IDs.
public static class WarcraftMenuDiscovery
{
    [StructLayout(LayoutKind.Sequential)]
    private struct MemoryInfo {
        public IntPtr BaseAddress, AllocationBase;
        public uint AllocationProtect;
        public UIntPtr RegionSize;
        public uint State, Protect, Type;
    }
    [DllImport("kernel32.dll", SetLastError=true)] private static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
    [DllImport("kernel32.dll")] private static extern bool CloseHandle(IntPtr handle);
    [DllImport("kernel32.dll", SetLastError=true)] private static extern UIntPtr VirtualQueryEx(IntPtr handle, IntPtr address, out MemoryInfo info, UIntPtr size);
    [DllImport("kernel32.dll", SetLastError=true)] private static extern bool ReadProcessMemory(IntPtr handle, IntPtr address, byte[] bytes, UIntPtr count, out UIntPtr read);
    private static readonly byte[][] Prefixes = {
        Encoding.ASCII.GetBytes("/webui/index.html?guid="),
        Encoding.ASCII.GetBytes("/webui-socket/")
    };
    private static string Search(byte[] bytes, int count) {
        foreach (var prefix in Prefixes) {
            for (int i=0; i<count-prefix.Length-11; i++) {
                if (bytes[i] != prefix[0]) continue;
                int j=1; while(j<prefix.Length && bytes[i+j]==prefix[j]) j++;
                if (j!=prefix.Length) continue;
                int start=i+j, end=start;
                while(end<count && bytes[end]>=48 && bytes[end]<=57) end++;
                if (end<count && end-start>=11 && end-start<=20)
                    return Encoding.ASCII.GetString(bytes,start,end-start);
            }
        }
        return null;
    }
    public static string FindLocalMenuSession(int pid) {
        if (!Environment.Is64BitProcess) throw new InvalidOperationException("A 64-bit process is required.");
        var process=Process.GetProcessById(pid);
        if (!process.ProcessName.Equals("Warcraft III",StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Only Warcraft III may be inspected.");
        IntPtr handle=OpenProcess(0x410,false,pid);
        if(handle==IntPtr.Zero) throw new InvalidOperationException("Read-only game inspection was denied.");
        var watch=Stopwatch.StartNew(); var bytes=new byte[1024*1024];
        ulong address=0,total=0;
        try {
            while(watch.ElapsedMilliseconds<12000 && total<2UL*1024*1024*1024) {
                MemoryInfo info;
                if(VirtualQueryEx(handle,new IntPtr((long)address),out info,(UIntPtr)Marshal.SizeOf<MemoryInfo>())==UIntPtr.Zero) break;
                ulong start=(ulong)info.BaseAddress.ToInt64(), end=start+info.RegionSize.ToUInt64();
                if(end<=address) break;
                if(info.State==0x1000 && info.Type==0x20000 && (info.Protect & 0x101)==0) {
                    for(ulong offset=start; offset<end && watch.ElapsedMilliseconds<12000 && total<2UL*1024*1024*1024;) {
                        int count=(int)Math.Min((ulong)bytes.Length,end-offset); UIntPtr read;
                        ReadProcessMemory(handle,new IntPtr((long)offset),bytes,(UIntPtr)count,out read);
                        total+=(ulong)count;
                        var found=Search(bytes,(int)read.ToUInt64());
                        if(found!=null) return found;
                        offset+=(ulong)(count>128 ? count-128 : count);
                    }
                }
                address=end;
            }
        } finally { CloseHandle(handle); }
        return null;
    }
}
