'use strict';
const fs = require('node:fs');
const path = require('node:path');
function selection(input) {
  if(!input || !Array.isArray(input.tags) || input.tags.length>12 || typeof input.includeTeam!=='boolean')
    throw new Error('Unrecognized saved friend settings.');
  const tags=input.tags.map(tag=>{
    if(typeof tag!=='string' || !/^[^\s#]{2,32}#\d{3,12}$/.test(tag.trim())) throw new Error('Invalid saved BattleTag.');
    return tag.trim();
  });
  return {tags:tags.filter((tag,i)=>tags.findIndex(t=>t.toLowerCase()===tag.toLowerCase())===i),includeTeam:input.includeTeam};
}
function loadPreferences(file) {
  try {
    if(fs.statSync(file).size>16384) throw new Error('Saved settings are too large.');
    return selection(JSON.parse(fs.readFileSync(file,'utf8')));
  } catch(error) {
    if(error.code==='ENOENT') return {tags:[],includeTeam:true};
    throw new Error('Saved friends could not be loaded. Add them again to save a new list.');
  }
}
function savePreferences(file,input) {
  const saved=selection(input);
  fs.mkdirSync(path.dirname(file),{recursive:true});
  const temporary=file+'.'+process.pid+'.tmp';
  try {
    fs.writeFileSync(temporary,JSON.stringify(saved,null,2)+'\n',{encoding:'utf8',mode:0o600});
    fs.renameSync(temporary,file);
  } finally {
    if(fs.existsSync(temporary)) fs.unlinkSync(temporary);
  }
  return saved;
}
module.exports={loadPreferences,savePreferences};
