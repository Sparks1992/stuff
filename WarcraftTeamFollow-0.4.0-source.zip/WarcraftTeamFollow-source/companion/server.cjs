'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {execFile} = require('node:child_process');
const {TeamFollow} = require('./team-follow.cjs');
const {loadPreferences,savePreferences} = require('./preferences.cjs');
const dataRoot = process.env.WF_DATA_DIR ? path.resolve(process.env.WF_DATA_DIR) : path.join(__dirname,'..');
const preferencesFile = path.join(dataRoot,'settings','friends.json');
let preferencesError='';
const token = crypto.randomBytes(24).toString('hex');
const runtimeDir = path.join(dataRoot,'runtime');
const runtimeFile = path.join(runtimeDir,'companion.json');
let ws, connecting = false, requestAt = 0, origin, shuttingDown = false, nextDiscovery = 0;
const allowed = new Set(['TeamGetInfo','FriendsGetFriends','RequestCancelTeamInvitations','TeamLeave','JoinFriendGameLobby','JoinGameByGameName']);
const engine = new TeamFollow({send(message,payload) {
  if(!allowed.has(message)) throw new Error('Unsupported game command.');
  if(!ws || ws.readyState !== WebSocket.OPEN) return false;
  ws.send(JSON.stringify({type:'webui',message,payload})); return true;
}});
try {engine.configure({...loadPreferences(preferencesFile),enabled:false});}
catch(_){preferencesError='Saved friends could not be loaded. Add them again to save a new list.';}
function stateSnapshot(){return {...engine.snapshot(),preferencesError};}
function discover() {
  if(process.env.WF_DISABLE_DISCOVERY==='1')return;
  if(shuttingDown || connecting || Date.now()<nextDiscovery || (ws && ws.readyState <= WebSocket.OPEN)) return;
  nextDiscovery = Date.now()+10000;
  connecting = true;
  const discoveryExe=process.env.WF_DISCOVERY_EXE;
  execFile(discoveryExe || 'pwsh.exe',discoveryExe?[]:['-NoProfile','-NonInteractive','-File',path.join(__dirname,'Get-MenuConnection.ps1')],
    {windowsHide:true,timeout:22000,maxBuffer:65536},(error,stdout) => {
      connecting = false;
      if(shuttingDown) return;
      if(error) { if(engine.connected) engine.connection(false); return; }
      let connection;
      try {
        connection = JSON.parse(stdout.trim());
        if(!Number.isInteger(connection.port) || connection.port < 1024 || connection.port > 65535 || !/^\d{11,20}$/.test(connection.session)) return;
      } catch (_) { return; }
      const socket = new WebSocket(`ws://127.0.0.1:${connection.port}/webui-socket/${connection.session}`);
      ws = socket; connection.session = null;
      const timeout = setTimeout(()=>{if(socket.readyState!==WebSocket.OPEN) socket.close();},5000);
      socket.addEventListener('open',()=> {
        clearTimeout(timeout); engine.connection(true,connection.version); requestAt = 0; refresh();
      });
      socket.addEventListener('message',e=> {
        if(ws!==socket) return;
        try { engine.receive(JSON.parse(String(e.data))); } catch (_) { engine.configure({enabled:false});engine.note('Unrecognized activity received. Follow is off.'); }
      });
      const closed = ()=> { clearTimeout(timeout); if(ws===socket) { ws=null; engine.connection(false); } };
      socket.addEventListener('close',closed);
      socket.addEventListener('error',()=> {try {socket.close();} catch (_) {} closed();});
    });
}
function refresh() {
  if(engine.connected && Date.now() - requestAt >= 5000) {
    requestAt = Date.now(); engine.send('TeamGetInfo',{}); engine.send('FriendsGetFriends',{});
  }
}
function json(res,status,value) {res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(value));}
const server = http.createServer(async(req,res)=> {
  if(req.headers.host!==new URL(origin).host) return json(res,403,{error:'Local access only.'});
  const url = new URL(req.url,origin);
  if(req.method==='GET' && url.pathname==='/api/state') return json(res,200,stateSnapshot());
  if(req.method==='GET' && url.pathname==='/api/diagnostics') return json(res,200,engine.diagnostics());
  if(req.method==='POST' && ['/api/config','/api/stop','/api/password'].includes(url.pathname)) {
    if(req.headers['x-wf-token']!==token || (req.headers.origin && req.headers.origin!==origin)) return json(res,403,{error:'Request denied.'});
    let raw='';
    try {
      for await (const part of req) {raw+=part;if(raw.length>4096) throw new Error('Request too large.');}
      if(url.pathname==='/api/stop') {json(res,200,{stopped:true});setTimeout(shutdown,50);return;}
      const input=JSON.parse(raw || '{}');
      if(!input || typeof input!=='object' || Array.isArray(input)) throw new Error('Invalid settings.');
      if(url.pathname==='/api/password'){engine.submitPassword(input.password);return json(res,200,stateSnapshot());}
      engine.configure(input);
      if('tags' in input || 'includeTeam' in input){
        try {
          savePreferences(preferencesFile,{tags:engine.manualTags,includeTeam:engine.includeTeam});
          preferencesError='';
        }catch(_){preferencesError='Your selection changed, but could not be saved on this PC. Try adding it again.';throw new Error(preferencesError);}
      }
      return json(res,200,stateSnapshot());
    } catch(e) {return json(res,400,{error:e.message || 'Invalid request.'});}
  }
  if(req.method!=='GET') return json(res,405,{error:'Unsupported request.'});
  const assets={'/':'index.html','/app.js':'app.js','/style.css':'style.css'};
  if(!assets[url.pathname]) return json(res,404,{error:'Not found.'});
  const file=assets[url.pathname];let content=fs.readFileSync(path.join(__dirname,'ui',file),'utf8');
  if(file==='index.html') content=content.replace('__WF_TOKEN__',token);
  res.writeHead(200,{'Content-Type':file.endsWith('.js')?'text/javascript; charset=utf-8':file.endsWith('.css')?'text/css; charset=utf-8':'text/html; charset=utf-8',
    'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer',
    'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'"});
  res.end(content);
});
const clock=setInterval(()=>{
  if(process.env.WF_PARENT_PID){try{process.kill(Number(process.env.WF_PARENT_PID),0);}catch(_){shutdown();return;}}
  engine.tick();refresh();discover();
},1000);
function shutdown() {
  shuttingDown=true;clearInterval(clock);engine.configure({enabled:false});if(ws) ws.close();server.close();
  try {const record=JSON.parse(fs.readFileSync(runtimeFile,'utf8'));if(record.pid===process.pid) fs.unlinkSync(runtimeFile);} catch(_){}
  setTimeout(()=>process.exit(0),100).unref();
}
server.listen(0,'127.0.0.1',()=> {
  origin=`http://127.0.0.1:${server.address().port}`;
  fs.mkdirSync(runtimeDir,{recursive:true});fs.writeFileSync(runtimeFile,JSON.stringify({url:origin,pid:process.pid}));
  console.log('Warcraft Team Follow: '+origin);discover();
});
server.on('error',()=>{console.error('The local companion could not start.');process.exit(1);});
process.on('SIGINT',shutdown);process.on('SIGTERM',shutdown);
