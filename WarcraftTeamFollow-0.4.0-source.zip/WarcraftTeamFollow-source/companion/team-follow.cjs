'use strict';
const { EventEmitter } = require('node:events');
const tagKey = value => String(value || '').trim().toLowerCase();
class TeamFollow extends EventEmitter {
  constructor({send = () => false, now = Date.now} = {}) {
    super(); this.send = send; this.now = now;
    this.connected = false; this.version = ''; this.enabled = false; this.diagnostic = true;
    this.team = []; this.teamAt = 0; this.watched = []; this.friends = new Map();
    this.status = 'Waiting for Warcraft III.'; this.busy = false; this.queued = false;
    this.screen = ''; this.pending = null; this.announced = new Set(); this.counts = {};
    this.log = []; this.lastJoin = null;
    this.manualTags = []; this.includeTeam = true;
    this.passwordRequest = null;
    this.inMatch = false; this.awaitingMenu = false; this.menuReady = false; this.resumeAt = 0;
    this.attempted = new Set(); this.presenceEpochs = new Map(); this.nextAttemptAt = 0;
  }
  note(message) {
    this.status = message;
    if(this.log.at(-1)?.message===message){this.emit('change');return;}
    this.log.push({time:new Date(this.now()).toISOString(),message});
    if(this.log.length > 40) this.log.shift(); this.emit('change');
  }
  connection(connected, version = '') {
    this.connected = connected; this.version = version;
    this.enabled = false; this.pending = null; this.passwordRequest = null; this.team = []; this.teamAt = 0;
    this.friends.clear(); this.watched = []; this.busy = false; this.queued = false; this.screen = '';
    this.inMatch = false; this.awaitingMenu = false; this.menuReady = false; this.resumeAt = 0;
    this.attempted.clear(); this.presenceEpochs.clear(); this.nextAttemptAt = 0;
    this.note(connected ? 'Connected. Form a team in Warcraft III; its members will appear here.' : 'Waiting for Warcraft III. Follow is off.');
  }
  configure(config) {
    if('tags' in config) {
      if(!Array.isArray(config.tags) || config.tags.length > 12) throw new Error('Add up to 12 friend BattleTags.');
      const tags = config.tags.map(tag => {
        if(typeof tag !== 'string' || !/^[^\s#]{2,32}#\d{3,12}$/.test(tag.trim()))
          throw new Error('Enter a full BattleTag, such as Friend#1234.');
        return tag.trim();
      });
      this.manualTags = tags.filter((tag,index) => tags.findIndex(t=>tagKey(t)===tagKey(tag))===index);
      this.enabled = false; this.pending = null; this.passwordRequest = null;
    }
    if('includeTeam' in config) {
      if(typeof config.includeTeam !== 'boolean') throw new Error('Choose whether to include your current team.');
      this.includeTeam = config.includeTeam; this.enabled = false; this.pending = null; this.passwordRequest = null;
    }
    if(typeof config.diagnostic === 'boolean' && this.diagnostic !== config.diagnostic) {
      this.enabled = false; this.pending = null; this.passwordRequest = null; this.diagnostic = config.diagnostic; this.announced.clear();
    }
    if(config.enabled === false) { this.enabled = false; this.pending = null; this.passwordRequest = null; this.note('Follow is off.'); return; }
    if(config.enabled === true) {
      if(this.pending) throw new Error('A join request is still pending. Check Warcraft III before trying again.');
      if(!this.connected) throw new Error('Start Warcraft III and wait for a connection first.');
      if(this.version !== '3.0.1.24371') throw new Error('This game build has not been verified. Monitoring is available; joining is disabled.');
      if(this.includeTeam && this.team.some(m=>!m.isSelf) && this.now() - this.teamAt > 20000)
        throw new Error('Waiting for a fresh team roster. Try again in a few seconds.');
      if(this.busy || this.queued || this.inMatch || this.awaitingMenu) throw new Error('Return to Custom Games before enabling Follow.');
      if(config.fromMenus !== true) throw new Error('Enable Follow while you are in the game menus.');
      const members = this.includeTeam ? this.team.filter(member => !member.isSelf && member.battleTag).map(m=>({...m})) : [];
      for(const tag of this.manualTags) {
        if(this.team.some(m=>m.isSelf && tagKey(m.battleTag)===tagKey(tag))) throw new Error('Choose a friend’s BattleTag, not your own.');
        const record = this.friends.get(tagKey(tag));
        if(!record || this.now()-record.seen > 20000) throw new Error('Waiting for friend activity for '+tag+'. Check the spelling and your Battle.net friends list.');
        if(record.data.isFriend !== true) throw new Error(tag+' must already be on your Battle.net friends list.');
        if(!members.some(m=>tagKey(m.battleTag)===tagKey(tag))) members.push({battleTag:record.data.battleTag,isFriend:true,isSelf:false});
      }
      if(!members.length) throw new Error('Invite a friend to your team or add a friend’s BattleTag first.');
      this.watched = members.map(m => ({...m})); this.enabled = true; this.pending = null; this.announced.clear();
      this.passwordRequest = null;
      this.attempted.clear(); this.nextAttemptAt = 0;
      // Demand a new status response after arming. Never act on a cached friend snapshot.
      this.armedAt = this.now(); this.friends.clear();
      this.note(this.diagnostic ? 'Watching selected players in diagnostics mode. No joining commands will be sent.' : 'Continuous Follow is on. Joining pauses in lobbies, matches and queues.');
      this.send('FriendsGetFriends', {});
    }
    this.evaluate(); this.emit('change');
  }
  receive(e) {
    if(!e || typeof e.messageType !== 'string') return;
    const type = e.messageType, p = e.payload || {};
    if(Object.keys(this.counts).length < 120 || this.counts[type]) this.counts[type] = (this.counts[type] || 0) + 1;
    switch(type) {
      case 'TeamsInformation': {
        const info = p.message;
        if(info && Array.isArray(info.partyMembers)) {
          this.team = info.partyMembers.filter(x => x && typeof x.battleTag === 'string').map(x => ({
            battleTag:x.battleTag, isSelf:x.isSelf === true, isFriend:x.isFriend === true,
            auroraId:x.auroraId, isOwner:x.isOwner === true
          })); this.teamAt = this.now();
        }
        break;
      }
      case 'TeamsLeft': case 'TeamsDisbanded': this.team = []; this.teamAt = 0; break;
      case 'FriendsFriendData':
        if(Array.isArray(p.data?.friends)) {
          this.friends.clear(); p.data.friends.forEach(f => this.friend(f));
        } break;
      case 'FriendsFriendUpdated': this.friend(p.data?.friend); break;
      case 'FriendsFriendRemoved': this.friends.clear(); break;
      case 'QueueEntered': this.queued = true; this.pause('Follow is on but paused for matchmaking.'); break;
      case 'QueueExited': this.queued = false; this.friends.clear();this.send('FriendsGetFriends',{});break;
      case 'RequestForPassword': this.confirmLobbyRequest(p); break;
      case 'GameLobbySetup':
        if(this.lastJoin && Array.isArray(p.players) && p.players.some(player=>player.isSelf===true && player.slotStatus===2)
          && (!this.lastJoin.lobby || p.lobbyName===this.lastJoin.lobby)) {
          if(!this.lastJoin.confirmed){this.lastJoin.confirmed = true;this.note('Joined '+this.lastJoin.friend+'’s lobby. Follow stays on and is paused here.');}
        } else if(this.pending) this.note('A lobby update arrived after the join request. Check the lobby in Warcraft III.');
        this.pending = null; this.passwordRequest = null; this.busy = true; this.awaitingMenu = false;this.menuReady = false;break;
      case 'IsGameUIActive':
        if(p.isActive === 'true' || p.isActive === true) { this.inMatch = true;this.busy = true;this.menuReady = false; this.pause('Follow is on but paused during the match.'); }
        else if(p.isActive==='false'||p.isActive===false){this.inMatch=false;}
        break;
      case 'MultiplayerGameJoinStarted':
        this.busy=true;this.menuReady=false;this.pause('Follow is on but paused while entering a lobby.');break;
      case 'PauseUI': case 'GameFound': case 'LoadingScreenUpdate':
        this.inMatch = true;this.busy = true;this.menuReady=false; this.pause('Follow is on but paused while the game enters a match.'); break;
      case 'MultiplayerGameLeave': case 'ExitedGame':
        if(type==='ExitedGame')this.inMatch=false;
        this.busy = true;this.awaitingMenu=true;this.menuReady=false;this.resumeAt=this.now()+2000;
        this.pending = null; this.passwordRequest = null;this.friends.clear();
        this.note(this.enabled?'Follow is still on. Return to Custom Games to resume automatically.':'Returned from a game or lobby. Follow is off.'); break;
      case 'GameList':
        // Only the game's own UI requests listings; this helper never requests them.
        // A listing after leaving provides evidence that Custom Games is open.
        if(this.awaitingMenu && !this.inMatch && !this.queued && Array.isArray(p.games))this.menuReady=true;
        break;
      case 'SetGlueScreen':
        this.screen = typeof p.screen === 'string' ? p.screen : '';
        if(['GAME_LOBBY','CUSTOM_GAME_LOBBY','LOADING_SCREEN','DISABLED_SCREEN','OUT_OF_MENUS','SCORE_SCREEN'].includes(this.screen)) {
          this.busy = true;this.menuReady=false;
          if(['LOADING_SCREEN','DISABLED_SCREEN','OUT_OF_MENUS'].includes(this.screen))this.inMatch=true;
          if(this.screen==='SCORE_SCREEN'){this.inMatch=false;this.awaitingMenu=true;this.resumeAt=this.now()+2000;}
          this.pause('Follow is on but paused in this lobby or game screen.');
        } else if(['MAIN_MENU','MULTIPLAYER','CUSTOM_LOBBIES','CHAT','VERSUS'].includes(this.screen)) {
          this.inMatch=false;
          if(this.busy||this.awaitingMenu){this.awaitingMenu=true;this.menuReady=true;this.resumeAt=Math.max(this.resumeAt,this.now()+2000);}
        }
        break;
      case 'LoggedOut': this.connection(false); break;
      case 'GameSearchFailedToJoinGame': case 'GameSearchGameNotFound':
        this.pending = null; this.passwordRequest = null;
        this.note('The game could not join that lobby. Follow stays on and waits for a new lobby.'); break;
    }
    this.resumeIfReady();
    this.evaluate(); this.emit('change');
  }
  friend(friend) {
    if(friend && typeof friend.battleTag === 'string') {
      const key=tagKey(friend.battleTag),attrs=Array.isArray(friend.localRichPresenceAttributes)?friend.localRichPresenceAttributes:[];
      const value=name=>attrs.find(a=>a.key===name)?.value||'';
      const open=friend.isOnline===true&&friend.isFriend===true&&friend.currentProgram==='W3'&&value('currentGameState')==='open';
      const signature=String(value('currentGameName'));
      const previous=this.presenceEpochs.get(key);
      const epoch=previous?previous.epoch+((open&&!previous.open)||(open&&signature!==previous.signature)?1:0):0;
      this.presenceEpochs.set(key,{open,signature,epoch});
      this.friends.set(key,{data:friend,seen:this.now(),epoch});
    }
  }
  pause(message) {this.pending=null;this.passwordRequest=null;if(this.enabled)this.note(message);}
  resumeIfReady(){
    if(!this.awaitingMenu||!this.menuReady||this.inMatch||this.queued||this.now()<this.resumeAt)return;
    this.busy=false;this.awaitingMenu=false;this.menuReady=false;
    this.friends.clear();this.send('FriendsGetFriends',{});
    if(this.enabled)this.note('Custom Games is ready. Continuous Follow has resumed automatically.');
  }
  confirmLobbyRequest(payload) {
    if(!this.enabled || !this.pending || this.diagnostic || !this.connected || this.busy || this.queued || this.inMatch) return;
    const name = payload.message?.matchJoinGameByNameText;
    if(typeof name!=='string' || !name || name.length>128 || (this.pending.lobby && name!==this.pending.lobby)) {
      this.pending = null; this.note('The lobby confirmation did not match the requested friend. Waiting for a new lobby.'); return;
    }
    if(this.pending.emptyConfirmationSent) {
      this.passwordRequest = {lobby:name,friend:this.pending.friend,started:this.now()};
      this.pending = null;
      this.note('The game is asking for a lobby password. Enter it below, or cancel.');return;
    }
    this.pending.emptyConfirmationSent = true; this.pending.started = this.now(); this.pending.lobby = name;
    if(this.lastJoin) this.lastJoin.lobby = name;
    try {
      if(this.send('JoinGameByGameName',{gameName:name,gamePass:''})===false) throw new Error();
      this.note('Completing the game’s lobby confirmation with no password. Waiting for the lobby.');
    } catch(_) {this.pending = null;this.note('The lobby confirmation could not be sent. Waiting for a new lobby.');}
  }
  submitPassword(password) {
    if(!this.passwordRequest || this.now()-this.passwordRequest.started>120000) throw new Error('The password request has expired. Start a new follow attempt.');
    if(!this.enabled || !this.connected || this.busy || this.queued || this.inMatch || this.diagnostic) throw new Error('Return to the game menus before joining.');
    if(typeof password!=='string' || password.length>128) throw new Error('Enter a valid lobby password.');
    const request=this.passwordRequest;this.passwordRequest=null;
    this.pending={friend:request.friend,lobby:request.lobby,started:this.now(),emptyConfirmationSent:true};
    try {
      if(this.send('JoinGameByGameName',{gameName:request.lobby,gamePass:password})===false) throw new Error();
      this.note('Lobby password submitted to the game. It has not been saved.');
    }catch(_){this.pending=null;throw new Error('The local game connection failed.');}
  }
  presence(member) {
    const record = this.friends.get(tagKey(member.battleTag));
    if(!record) return {label:member.isFriend ? 'Waiting for activity' : 'Friend activity unavailable',open:false};
    const f = record.data, attrs = Array.isArray(f.localRichPresenceAttributes) ? f.localRichPresenceAttributes : [];
    const attribute = name => attrs.find(a=>a.key === name)?.value;
    const fresh = this.now() - record.seen < 20000;
    const accountIdValid = (typeof f.accountId === 'number' && Number.isSafeInteger(f.accountId) && f.accountId > 0)
      || (typeof f.accountId === 'string' && /^\d{1,20}$/.test(f.accountId) && !/^0+$/.test(f.accountId));
    const open = fresh && f.isOnline === true && f.isFriend === true && f.currentProgram === 'W3'
      && attribute('currentGameState') === 'open' && accountIdValid;
    return {label:!fresh ? 'Activity is stale' : !f.isOnline ? 'Offline' : open ? 'Lobby is joinable' : f.currentProgram === 'W3' ? 'In Warcraft III' : 'Online in Battle.net',
      open, auroraId:f.accountId, lobby:attribute('currentGameName') || '',epoch:record.epoch};
  }
  evaluate() {
    if(!this.enabled || !this.connected || this.busy || this.queued || this.inMatch || this.awaitingMenu || this.pending || this.passwordRequest || this.now()<this.nextAttemptAt) return;
    const candidates = this.watched.map(member=>({member,presence:this.presence(member)})).filter(x=>x.presence.open&&!this.attempted.has(tagKey(x.member.battleTag)+':'+x.presence.epoch+':'+x.presence.lobby));
    if(!candidates.length) return;
    // Team order supplies a deterministic choice if more than one member becomes joinable together.
    const {member,presence} = candidates[0];
    const marker = tagKey(member.battleTag) + ':' + presence.lobby;
    if(this.diagnostic) {
      if(!this.announced.has(marker)) { this.announced.add(marker); this.note('Ready to follow ' + member.battleTag + '. Diagnostics mode prevented joining.'); }
      return;
    }
    // Attempt each observed lobby once. A closed/reopened or renamed lobby is a new opportunity.
    this.attempted.add(tagKey(member.battleTag)+':'+presence.epoch+':'+presence.lobby);
    if(this.attempted.size>256)this.attempted.delete(this.attempted.values().next().value);
    this.nextAttemptAt=this.now()+10000;
    this.pending = {started:this.now(),friend:member.battleTag,lobby:presence.lobby,emptyConfirmationSent:false};
    this.lastJoin = {friend:member.battleTag,lobby:presence.lobby,time:new Date(this.now()).toISOString(),confirmed:false};
    try {
      if(this.send('RequestCancelTeamInvitations', {}) === false) throw new Error();
      if(this.team.filter(m=>!m.isSelf).length && this.send('TeamLeave', {}) === false) throw new Error();
      if(this.send('JoinFriendGameLobby', {auroraId:presence.auroraId}) === false) throw new Error();
      this.note('Requested to join ' + member.battleTag + '. Continuous Follow remains on.');
    } catch (_) { this.pending = null; this.note('The local join request failed. Waiting for a new lobby.'); }
  }
  tick() {
    this.resumeIfReady();
    if(this.passwordRequest && this.now()-this.passwordRequest.started>120000){this.passwordRequest=null;this.note('The lobby password request expired. Waiting for a new lobby.');}
    if(this.pending && this.now() - this.pending.started > 15000) {
      this.pending = null; this.note('No lobby update confirmed the request. Check the game before trying again.');
    }
    this.evaluate();
  }
  snapshot() {
    return {connected:this.connected,version:this.version,enabled:this.enabled,diagnostic:this.diagnostic,
      manualTags:this.manualTags.slice(),includeTeam:this.includeTeam,
      status:this.status,screen:this.screen,busy:this.busy,queued:this.queued,joinPending:Boolean(this.pending),passwordRequest:this.passwordRequest?{lobby:this.passwordRequest.lobby,friend:this.passwordRequest.friend}:null,
      inMatch:this.inMatch,paused:this.enabled&&(this.busy||this.queued||this.inMatch||this.awaitingMenu),
      team:this.team.map(m=>({...m,auroraId:undefined,status:m.isSelf ? 'You' : this.presence(m).label})),
      watched:this.watched.map(m=>({battleTag:m.battleTag,...this.presence(m),auroraId:undefined})),
      lastJoin:this.lastJoin,log:this.log.slice()};
  }
  diagnostics() {
    return {version:this.version,connected:this.connected,screen:this.screen,teamCount:this.team.length,
      watchedCount:this.watched.length,friendCount:this.friends.size,eventCounts:{...this.counts},
      diagnostic:this.diagnostic,enabled:this.enabled,busy:this.busy,queued:this.queued};
  }
}
module.exports = {TeamFollow};
