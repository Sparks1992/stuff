'use strict';
const $=id=>document.getElementById(id);
const token=document.querySelector('meta[name="wf-token"]').content;
let state=null, editing=false;
async function config(value) {
  $('error').textContent='';
  try {
    const response=await fetch('/api/config',{method:'POST',headers:{'Content-Type':'application/json','X-WF-Token':token},body:JSON.stringify(value)});
    const data=await response.json();if(!response.ok) throw new Error(data.error);render(data);
  } catch(e) {$('error').textContent=e.message;}
}
function memberRow(name,status,open) {
  const row=document.createElement('div');row.className='member';
  const label=document.createElement('span');label.className='member-name';label.textContent=name;
  const activity=document.createElement('span');activity.className='member-state'+(open?' open':'');activity.textContent=status;
  row.append(label,activity);return row;
}
function list(id,rows,empty) {
  const root=$(id);root.replaceChildren();
  if(!rows.length){const p=document.createElement('p');p.className='empty';p.textContent=empty;root.append(p);}
  else rows.forEach(row=>root.append(row));
}
function render(data) {
  state=data;$('status').textContent=data.status;
  $('password-panel').hidden=!data.passwordRequest;
  $('password-target').textContent=data.passwordRequest?'The game requested a password for '+data.passwordRequest.lobby+'.':'';
  if(!data.passwordRequest)$('lobby-password').value='';
  $('connection').textContent=data.connected?'Game connected':'Waiting for game';
  $('connection').classList.toggle('connected',data.connected);
  $('team-count').textContent=data.team.length;
  list('team',data.team.map(m=>memberRow(m.battleTag+(m.isSelf?' · you':''),m.status,false)),data.connected?'No team roster yet. Form a team in the game.':'Start Warcraft III to read your team.');
  list('watched',data.watched.map(m=>memberRow(m.battleTag,m.label,m.open)),'Enable watching to remember the selected players.');
  $('include-team').checked=data.includeTeam;
  $('saved-friends').textContent=data.preferencesError||'Friends and team selection are saved automatically on this PC.';
  $('saved-friends').classList.toggle('error',Boolean(data.preferencesError));
  const tagsSignature=JSON.stringify(data.manualTags);
  if($('friend-tags').dataset.tags!==tagsSignature){
  $('friend-tags').dataset.tags=tagsSignature;
  $('friend-tags').replaceChildren();data.manualTags.forEach(tag=>{
    const chip=document.createElement('span');chip.className='tag-chip';
    const name=document.createElement('span');name.textContent=tag;
    const remove=document.createElement('button');remove.type='button';remove.textContent='×';remove.setAttribute('aria-label','Remove '+tag);
    remove.onclick=()=>config({enabled:false,tags:state.manualTags.filter(t=>t!==tag)});
    chip.append(name,remove);$('friend-tags').append(chip);
  });
  }
  $('mode').textContent=data.enabled?(data.paused?'Follow on · paused':data.joinPending?'Follow on · joining':data.diagnostic?'Watching · diagnostics':'Continuous Follow on'):'Following is off';
  const hasTargets=(data.includeTeam&&data.team.some(m=>!m.isSelf))||data.manualTags.length>0;
  $('enable').disabled=!data.connected||!hasTargets||!$('menus').checked||data.busy||data.queued||data.joinPending;
  $('disable').disabled=!data.enabled;
  $('enable').textContent=data.enabled?'Refresh selected players':'Watch selected players';
  if(!editing)$('diagnostic').checked=data.diagnostic;
  $('hint').textContent=!data.connected?'Start the game normally through Battle.net. No game-file installation is required.':data.paused?'Follow stays enabled. Return to Custom Games after your lobby, match or queue to resume automatically.':!hasTargets?'Form a team or add a friend’s BattleTag, then enable watching here.':'Once enabled, Follow stays on and automatically pauses during games. Stop following turns it off.';
  $('version').textContent='Prototype 0.3 · '+(data.version?'Warcraft III '+data.version:'Local companion');
  $('activity').replaceChildren();data.log.slice(-8).reverse().forEach(entry=> {
    const li=document.createElement('li'),time=document.createElement('time'),text=document.createElement('span');
    time.textContent=new Date(entry.time).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});text.textContent=entry.message;
    li.append(time,text);$('activity').append(li);
  });
}
$('menus').onchange=()=>{if(state)render(state);};
$('cancel-password').onclick=()=>config({enabled:false});
$('password-form').onsubmit=async event=>{
  event.preventDefault();$('error').textContent='';
  let password=$('lobby-password').value;$('lobby-password').value='';
  try{
    const r=await fetch('/api/password',{method:'POST',headers:{'Content-Type':'application/json','X-WF-Token':token},body:JSON.stringify({password})});
    password='';const data=await r.json();if(!r.ok)throw new Error(data.error);render(data);
  }catch(e){$('error').textContent=e.message;}finally{password='';}
};
$('include-team').onchange=()=>config({enabled:false,includeTeam:$('include-team').checked});
$('friend-form').onsubmit=async event=>{
  event.preventDefault();const tag=$('friend-tag').value.trim();
  if(!tag)return;
  await config({enabled:false,tags:[...state.manualTags,tag]});
  if(!$('error').textContent)$('friend-tag').value='';
};
$('enable').onclick=()=>config({enabled:true,diagnostic:$('diagnostic').checked,fromMenus:$('menus').checked});
$('disable').onclick=()=>config({enabled:false});
$('diagnostic').onchange=async()=>{editing=true;await config({enabled:false,diagnostic:$('diagnostic').checked});editing=false;};
$('diagnostics').onclick=async()=>{const r=await fetch('/api/diagnostics');$('report').value=JSON.stringify(await r.json(),null,2);$('report').hidden=false;};
$('quit').onclick=async()=>{await fetch('/api/stop',{method:'POST',headers:{'X-WF-Token':token}});$('status').textContent='Helper stopped. You can close this page.';clearInterval(poll);};
async function update(){try{const r=await fetch('/api/state');render(await r.json());}catch(_){$('connection').textContent='Helper stopped';$('enable').disabled=true;$('disable').disabled=true;}}
const poll=setInterval(update,1500);update();
