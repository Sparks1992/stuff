[CmdletBinding()]
param([string]$Version='0.4.0')
$ErrorActionPreference='Stop'
$projectRoot=Split-Path -Parent $PSScriptRoot
$compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$framework=Split-Path -Parent $compiler
if(-not(Test-Path -LiteralPath $compiler)){throw 'The .NET Framework C# compiler is required to build this package.'}
$releaseName='WarcraftTeamFollow-'+$Version+'-win-x64'
$buildRoot=Join-Path $projectRoot ('build\'+$releaseName)
$payloadRoot=Join-Path $buildRoot 'payload'
$appRoot=Join-Path $payloadRoot 'app'
$releaseRoot=Join-Path $projectRoot ('releases\'+$releaseName)
New-Item -ItemType Directory -Path $buildRoot,$payloadRoot,$appRoot,$releaseRoot,(Join-Path $payloadRoot 'runtime'),(Join-Path $appRoot 'ui'),(Join-Path $payloadRoot 'licenses') -Force | Out-Null
$node=(Get-Command node.exe -ErrorAction Stop).Source
$nodeVersion=(& $node --version).Trim()
$nodeLicense=Join-Path $PSScriptRoot 'vendor\Node-LICENSE.txt'
if(-not(Test-Path -LiteralPath $nodeLicense)){throw 'Obtain the exact Node.js version license before building.'}
Copy-Item -LiteralPath $node -Destination (Join-Path $payloadRoot 'runtime\node.exe') -Force
Copy-Item -LiteralPath $nodeLicense -Destination (Join-Path $payloadRoot 'licenses\Node-LICENSE.txt') -Force
foreach($name in @('server.cjs','team-follow.cjs','preferences.cjs')){Copy-Item -LiteralPath (Join-Path $projectRoot ('companion\'+$name)) -Destination (Join-Path $appRoot $name) -Force}
foreach($name in @('index.html','app.js','style.css')){Copy-Item -LiteralPath (Join-Path $projectRoot ('companion\ui\'+$name)) -Destination (Join-Path $appRoot ('ui\'+$name)) -Force}
$assemblyFile=Join-Path $buildRoot 'AssemblyInfo.cs'
$assemblySource=@"
using System.Reflection;
[assembly:AssemblyTitle("Warcraft Team Follow")]
[assembly:AssemblyProduct("Warcraft Team Follow")]
[assembly:AssemblyDescription("Unofficial local Warcraft III friend-lobby companion")]
[assembly:AssemblyVersion("$Version.0")]
[assembly:AssemblyFileVersion("$Version.0")]
"@
[IO.File]::WriteAllText($assemblyFile,$assemblySource)
$iconFile=Join-Path $buildRoot 'follow.ico'
Add-Type -AssemblyName System.Drawing
$bitmap=[Drawing.Bitmap]::new(64,64)
$graphics=[Drawing.Graphics]::FromImage($bitmap)
$graphics.Clear([Drawing.Color]::FromArgb(18,24,32))
$pen=[Drawing.Pen]::new([Drawing.Color]::FromArgb(216,188,130),2)
$graphics.DrawRectangle($pen,4,4,55,55)
$font=[Drawing.Font]::new('Georgia',31,[Drawing.FontStyle]::Regular,[Drawing.GraphicsUnit]::Pixel)
$brush=[Drawing.SolidBrush]::new([Drawing.Color]::FromArgb(216,188,130))
$graphics.DrawString('W',$font,$brush,11,13)
$icon=[Drawing.Icon]::FromHandle($bitmap.GetHicon())
$iconStream=[IO.File]::Create($iconFile)
$icon.Save($iconStream)
$iconStream.Dispose();$icon.Dispose();$graphics.Dispose();$bitmap.Dispose();$pen.Dispose();$font.Dispose();$brush.Dispose()
$references=@('/r:System.Windows.Forms.dll','/r:System.Drawing.dll','/r:System.Web.Extensions.dll',('/r:'+(Join-Path $framework 'System.Net.Http.dll')))
& $compiler /nologo /optimize+ /platform:x64 /target:exe ('/out:'+(Join-Path $payloadRoot 'WarcraftMenuDiscovery.exe')) @references (Join-Path $PSScriptRoot 'NativeDiscovery.cs') (Join-Path $projectRoot 'companion\MenuDiscovery.cs') $assemblyFile
if($LASTEXITCODE -ne 0){throw 'Native game discovery compilation failed.'}
& $compiler /nologo /optimize+ /platform:x64 /target:winexe ('/win32icon:'+$iconFile) ('/out:'+(Join-Path $payloadRoot 'WarcraftTeamFollow.App.exe')) @references (Join-Path $PSScriptRoot 'DesktopApp.cs') $assemblyFile
if($LASTEXITCODE -ne 0){throw 'Desktop interface compilation failed.'}
$config='<?xml version="1.0"?><configuration><startup><supportedRuntime version="v4.0" sku=".NETFramework,Version=v4.8"/></startup></configuration>'
[IO.File]::WriteAllText((Join-Path $payloadRoot 'WarcraftTeamFollow.App.exe.config'),$config)
$readme=@"
Warcraft Team Follow $Version - Windows 10/11, 64-bit

Run WarcraftTeamFollow.exe. No Node.js or PowerShell installation is required.
Requires .NET Framework 4.8 (included with Windows 11 and current Windows 10).
The first launch unpacks the app into your Windows local application-data folder.
Each user's saved friends are stored separately in:
%LOCALAPPDATA%\WarcraftTeamFollow\settings\friends.json

Start Warcraft III normally through Battle.net. In this app, add your friends' full
BattleTags or include your current team. Open Custom Games, acknowledge the menu,
and enable watching. Diagnostics mode checks activity without joining. Turn it off
to allow live joining. Follow stays enabled and pauses in lobbies, games and queues.
Close the desktop app to stop its background helper.

Verified game build: 3.0.1.24371. New game builds require verification before live joins.
Each friend must already be on your own Battle.net friends list. An entire live
match-cycle test remains pending; the single open-lobby join was verified live.

This is an unofficial, unsigned application, not a Blizzard product. It uses
read-only local menu-session discovery and the game's own local menu commands.
It does not modify game files or memory and includes no Warcraft III assets.
No claim of Blizzard approval or account-safety certification is made.
Your friends' accounts and settings are not included in this distribution.

Included runtime: Node.js $nodeVersion. Its complete third-party notices are
bundled in licenses\Node-LICENSE.txt in the extracted application folder.
"@
[IO.File]::WriteAllText((Join-Path $payloadRoot 'README.txt'),$readme)
[IO.File]::WriteAllText((Join-Path $releaseRoot 'README.txt'),$readme)
$payloadZip=Join-Path $buildRoot 'payload.zip'
Compress-Archive -Path (Join-Path $payloadRoot '*') -DestinationPath $payloadZip -CompressionLevel Optimal -Force
$hash=(Get-FileHash -LiteralPath $payloadZip -Algorithm SHA256).Hash.ToLowerInvariant()
$buildInfo=Join-Path $buildRoot 'BuildInfo.cs'
[IO.File]::WriteAllText($buildInfo,('internal static class BuildInfo { internal const string Version="'+$Version+'"; internal const string PayloadHash="'+$hash+'"; }'))
$output=Join-Path $releaseRoot 'WarcraftTeamFollow.exe'
& $compiler /nologo /optimize+ /platform:x64 /target:winexe ('/win32icon:'+$iconFile) ('/out:'+$output) '/r:System.Windows.Forms.dll' '/r:System.IO.Compression.dll' ('/resource:'+$payloadZip+',Bundle.Payload.zip') (Join-Path $PSScriptRoot 'BundleLauncher.cs') $buildInfo $assemblyFile
if($LASTEXITCODE -ne 0){throw 'Single executable packaging failed.'}
$fileHash=(Get-FileHash -LiteralPath $output -Algorithm SHA256).Hash.ToLowerInvariant()
[IO.File]::WriteAllText((Join-Path $releaseRoot 'SHA256SUMS.txt'),$fileHash+'  WarcraftTeamFollow.exe'+[Environment]::NewLine)
$releaseZip=Join-Path $projectRoot ('releases\'+$releaseName+'.zip')
Compress-Archive -Path (Join-Path $releaseRoot '*') -DestinationPath $releaseZip -CompressionLevel Optimal -Force
[pscustomobject]@{Executable=$output;ShareableZip=$releaseZip;SizeMB=[math]::Round((Get-Item -LiteralPath $output).Length/1MB,1);SHA256=$fileHash}
