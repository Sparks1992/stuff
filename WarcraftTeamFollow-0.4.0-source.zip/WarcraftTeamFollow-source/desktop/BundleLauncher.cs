using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;
using System.Threading;
using System.Windows.Forms;

internal static class BundleLauncher {
    private static string Quote(string value){return "\""+value.Replace("\"","\\\"")+"\"";}
    [STAThread]public static int Main(string[] args){
        bool selfTest=args.Length==2&&args[0]=="--self-test";
        try {
            string root=selfTest?Path.Combine(Path.GetDirectoryName(Path.GetFullPath(args[1])),"bundle-test-cache"):Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"WarcraftTeamFollow","app");
            string destination=Path.Combine(root,BuildInfo.Version+"-"+BuildInfo.PayloadHash.Substring(0,12));
            string marker=Path.Combine(destination,".complete");
            using(var mutex=new Mutex(false,"Local\\WarcraftTeamFollow.Extract."+BuildInfo.PayloadHash.Substring(0,16))){
                if(!mutex.WaitOne(TimeSpan.FromSeconds(40)))throw new InvalidOperationException("Another copy is preparing the app. Try again shortly.");
                try {
                    if(!File.Exists(marker)||File.ReadAllText(marker)!=BuildInfo.PayloadHash){
                        using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("Bundle.Payload.zip")){
                            if(stream==null)throw new InvalidOperationException("The app bundle is incomplete.");
                            using(var sha=SHA256.Create()){
                                string hash=BitConverter.ToString(sha.ComputeHash(stream)).Replace("-","").ToLowerInvariant();
                                if(hash!=BuildInfo.PayloadHash)throw new InvalidOperationException("The app bundle failed its integrity check. Download it again.");
                            }
                            stream.Position=0;Directory.CreateDirectory(destination);
                            using(var zip=new ZipArchive(stream,ZipArchiveMode.Read)){
                                string prefix=Path.GetFullPath(destination)+Path.DirectorySeparatorChar;
                                foreach(var entry in zip.Entries){
                                    string file=Path.GetFullPath(Path.Combine(destination,entry.FullName));
                                    if(!file.StartsWith(prefix,StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Invalid bundled path.");
                                    if(entry.FullName.EndsWith("/")){Directory.CreateDirectory(file);continue;}
                                    Directory.CreateDirectory(Path.GetDirectoryName(file));
                                    using(var input=entry.Open())using(var output=new FileStream(file,FileMode.Create,FileAccess.Write,FileShare.None)){input.CopyTo(output);}
                                }
                            }
                        }
                        File.WriteAllText(marker,BuildInfo.PayloadHash);
                    }
                }finally{mutex.ReleaseMutex();}
            }
            string executable=Path.Combine(destination,"WarcraftTeamFollow.App.exe");
            string arguments=selfTest?"--self-test "+Quote(Path.GetFullPath(args[1])):"";
            using(var process=Process.Start(new ProcessStartInfo(executable,arguments){UseShellExecute=false,WorkingDirectory=destination,CreateNoWindow=true,WindowStyle=selfTest?ProcessWindowStyle.Hidden:ProcessWindowStyle.Normal})){
                if(selfTest){process.WaitForExit();return process.ExitCode;}
            }
            return 0;
        }catch(Exception ex){
            if(selfTest){File.WriteAllText(Path.GetFullPath(args[1]),"{\"success\":false,\"error\":\"Bundle startup failed\"}");return 1;}
            MessageBox.Show(ex.Message,"Warcraft Team Follow",MessageBoxButtons.OK,MessageBoxIcon.Error);return 1;
        }
    }
}
