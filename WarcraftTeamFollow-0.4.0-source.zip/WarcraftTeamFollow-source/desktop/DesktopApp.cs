using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

internal static class Json {
    internal static readonly JavaScriptSerializer Codec=new JavaScriptSerializer();
    internal static Dictionary<string,object> Parse(string value){return Codec.DeserializeObject(value) as Dictionary<string,object> ?? new Dictionary<string,object>();}
    internal static object Value(Dictionary<string,object> value,string key){object result;return value!=null&&value.TryGetValue(key,out result)?result:null;}
    internal static string Text(Dictionary<string,object> value,string key){return Convert.ToString(Value(value,key))??"";}
    internal static bool Flag(Dictionary<string,object> value,string key){return Value(value,key) is bool && (bool)Value(value,key);}
    internal static List<Dictionary<string,object>> Rows(Dictionary<string,object> value,string key){var list=Value(value,key) as IEnumerable;return list==null?new List<Dictionary<string,object>>():list.Cast<object>().OfType<Dictionary<string,object>>().ToList();}
    internal static string[] Strings(Dictionary<string,object> value,string key){var list=Value(value,key) as IEnumerable;return list==null?new string[0]:list.Cast<object>().Select(Convert.ToString).ToArray();}
}

internal sealed class LocalEngine:IDisposable {
    private Process backend;private HttpClient http;private IntPtr job;
    internal string DataDirectory;
    [StructLayout(LayoutKind.Sequential)]private struct BasicLimits {public long ProcessTime,JobTime;public uint Flags;public UIntPtr Minimum,Maximum;public uint ActiveProcesses;public UIntPtr Affinity;public uint Priority,Scheduling;}
    [StructLayout(LayoutKind.Sequential)]private struct Counters {public ulong ReadOperations,WriteOperations,OtherOperations,ReadBytes,WriteBytes,OtherBytes;}
    [StructLayout(LayoutKind.Sequential)]private struct Limits {public BasicLimits Basic;public Counters Io;public UIntPtr ProcessMemory,JobMemory,PeakProcessMemory,PeakJobMemory;}
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)]private static extern IntPtr CreateJobObject(IntPtr security,string name);
    [DllImport("kernel32.dll")]private static extern bool SetInformationJobObject(IntPtr job,int infoClass,IntPtr info,uint length);
    [DllImport("kernel32.dll")]private static extern bool AssignProcessToJobObject(IntPtr job,IntPtr process);
    [DllImport("kernel32.dll")]private static extern bool CloseHandle(IntPtr handle);
    internal bool Running {get {try{return backend!=null&&!backend.HasExited;}catch{return false;}}}
    internal async Task Start(string dataDirectory,bool testOnly) {
        string root=AppDomain.CurrentDomain.BaseDirectory;
        string node=Path.Combine(root,"runtime","node.exe"),server=Path.Combine(root,"app","server.cjs"),discovery=Path.Combine(root,"WarcraftMenuDiscovery.exe");
        if(!File.Exists(node)||!File.Exists(server)||!File.Exists(discovery))throw new InvalidOperationException("The application bundle is incomplete. Download the complete executable again.");
        DataDirectory=dataDirectory;Directory.CreateDirectory(DataDirectory);
        var info=new ProcessStartInfo(node,"\""+server+"\""){WorkingDirectory=root,UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden};
        info.EnvironmentVariables["WF_DATA_DIR"]=DataDirectory;
        info.EnvironmentVariables["WF_DISCOVERY_EXE"]=discovery;
        info.EnvironmentVariables["WF_DISABLE_DISCOVERY"]=testOnly?"1":"0";
        info.EnvironmentVariables["WF_PARENT_PID"]=Process.GetCurrentProcess().Id.ToString();
        backend=Process.Start(info);AttachJob();
        string recordFile=Path.Combine(DataDirectory,"runtime","companion.json");
        for(int i=0;i<80;i++) {
            await Task.Delay(125);
            if(!Running)throw new InvalidOperationException("The local helper could not start. Close the app and try again.");
            if(!File.Exists(recordFile))continue;
            try {
                var record=Json.Parse(File.ReadAllText(recordFile));
                if(Convert.ToInt32(Json.Value(record,"pid"))!=backend.Id)continue;
                var uri=new Uri(Json.Text(record,"url"));
                if(uri.Scheme!="http"||uri.Host!="127.0.0.1"||uri.Port<1024)continue;
                var handler=new HttpClientHandler {UseProxy=false};
                http=new HttpClient(handler){BaseAddress=uri,Timeout=TimeSpan.FromSeconds(4)};
                string page=await http.GetStringAsync("/");
                var token=Regex.Match(page,"name=\"wf-token\" content=\"([a-f0-9]{48})\"");
                if(!token.Success)throw new InvalidOperationException("The local helper did not start correctly.");
                http.DefaultRequestHeaders.Add("X-WF-Token",token.Groups[1].Value);
                return;
            }catch(IOException){}catch(HttpRequestException){}catch(System.Threading.Tasks.TaskCanceledException){}
        }
        throw new InvalidOperationException("The local helper did not become ready. Close the app and try again.");
    }
    private void AttachJob() {
        job=CreateJobObject(IntPtr.Zero,null);if(job==IntPtr.Zero)return;
        var value=new Limits();value.Basic.Flags=0x2000;
        int size=Marshal.SizeOf(typeof(Limits));IntPtr memory=Marshal.AllocHGlobal(size);
        try {Marshal.StructureToPtr(value,memory,false);if(!SetInformationJobObject(job,9,memory,(uint)size)||!AssignProcessToJobObject(job,backend.Handle)){CloseHandle(job);job=IntPtr.Zero;}}
        finally {Marshal.FreeHGlobal(memory);}
    }
    internal async Task<Dictionary<string,object>> Get(string route){return Json.Parse(await http.GetStringAsync(route));}
    internal async Task<Dictionary<string,object>> Post(string route,object value){
        using(var body=new StringContent(Json.Codec.Serialize(value),Encoding.UTF8,"application/json"))
        using(var response=await http.PostAsync(route,body)) {
            var result=Json.Parse(await response.Content.ReadAsStringAsync());
            if(!response.IsSuccessStatusCode)throw new InvalidOperationException(Json.Text(result,"error"));
            return result;
        }
    }
    internal async Task Stop(){try{if(http!=null&&Running)await Post("/api/stop",new {});}catch{}finally{Dispose();}}
    public void Dispose(){
        if(job!=IntPtr.Zero){CloseHandle(job);job=IntPtr.Zero;}
        try{if(backend!=null&&!backend.HasExited)backend.Kill();}catch{}
        if(backend!=null){backend.Dispose();backend=null;}
        if(http!=null){http.Dispose();http=null;}
    }
}

internal sealed class FollowWindow:Form {
    [DllImport("user32.dll",CharSet=CharSet.Unicode)]private static extern IntPtr SendMessage(IntPtr handle,uint message,IntPtr wParam,string text);
    private readonly LocalEngine engine=new LocalEngine();
    private readonly System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer();
    private readonly Color background=Color.FromArgb(16,21,28),card=Color.FromArgb(25,32,41),muted=Color.FromArgb(153,168,185),gold=Color.FromArgb(217,190,137);
    private Label status,mode,error,saved,passwordTarget;private CheckBox includeTeam,diagnostic,menus;
    private TextBox tag,password;private ListBox savedTags;private ListView team,watched;private TextBox activity;private Panel passwordBar;
    private Button watch,stop,add,remove,joinPassword,report;
    private Dictionary<string,object> state;private bool updating,polling,closing;private int generation,failures;
    internal FollowWindow(){
        Text="Warcraft Team Follow";Size=new Size(1100,890);MinimumSize=new Size(960,760);StartPosition=FormStartPosition.CenterScreen;
        BackColor=background;ForeColor=Color.FromArgb(235,237,240);Font=new Font("Segoe UI",9.5f);AutoScaleMode=AutoScaleMode.Dpi;
        try{Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath);}catch{}
        var root=new TableLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(18),ColumnCount=1,RowCount=6};
        root.RowStyles.Add(new RowStyle(SizeType.Absolute,62));root.RowStyles.Add(new RowStyle(SizeType.Absolute,66));
        root.RowStyles.Add(new RowStyle(SizeType.Percent,55));root.RowStyles.Add(new RowStyle(SizeType.Percent,25));root.RowStyles.Add(new RowStyle(SizeType.Percent,20));root.RowStyles.Add(new RowStyle(SizeType.Absolute,30));Controls.Add(root);
        var header=new Panel{Dock=DockStyle.Fill};header.Controls.Add(new Label{Text="Go where your friends go.",Font=new Font("Georgia",24),AutoSize=true,Location=new Point(0,0)});
        header.Controls.Add(new Label{Text="WARCRAFT III  ·  TEAM FOLLOW 0.4",ForeColor=gold,AutoSize=true,Location=new Point(2,41)});
        mode=new Label{Dock=DockStyle.Right,Width=230,TextAlign=ContentAlignment.MiddleRight,ForeColor=muted,Text="Starting…"};header.Controls.Add(mode);root.Controls.Add(header,0,0);
        status=new Label{Dock=DockStyle.Fill,BackColor=card,Padding=new Padding(14),Text="Starting the local helper…",TextAlign=ContentAlignment.MiddleLeft};root.Controls.Add(status,0,1);
        var columns=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,Margin=new Padding(0,10,0,6)};columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,46));columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,54));root.Controls.Add(columns,0,2);
        var teamPanel=Card("Your current team");teamPanel.Margin=new Padding(0,0,8,0);columns.Controls.Add(teamPanel,0,0);team=List();teamPanel.Controls.Add(team);teamPanel.Controls.Add(Foot("Team members come directly from Warcraft III.\r\nYou can also add individual friends on the right.",42));team.BringToFront();
        var choices=Card("Choose whom to follow");choices.Margin=new Padding(8,0,0,0);columns.Controls.Add(choices,1,0);
        var selection=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=8};
        foreach(int height in new[]{28,34,60,30,28,42,40,35})selection.RowStyles.Add(new RowStyle(SizeType.Absolute,height));choices.Controls.Add(selection);selection.BringToFront();
        includeTeam=Check("Include my current team",true);selection.Controls.Add(includeTeam,0,0);
        var entry=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=3};entry.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));entry.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,66));entry.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,78));
        tag=Input(false);tag.MaxLength=46;tag.AccessibleName="Friend BattleTag";tag.HandleCreated+=delegate{SendMessage(tag.Handle,0x1501,new IntPtr(1),"Friend#1234");};add=Button("Add",false);remove=Button("Remove",false);entry.Controls.Add(tag,0,0);entry.Controls.Add(add,1,0);entry.Controls.Add(remove,2,0);selection.Controls.Add(entry,0,1);
        savedTags=new ListBox{Dock=DockStyle.Fill,BackColor=background,ForeColor=gold,BorderStyle=BorderStyle.FixedSingle,IntegralHeight=false};selection.Controls.Add(savedTags,0,2);
        saved=new Label{Dock=DockStyle.Fill,ForeColor=muted,Text="Friends save automatically on this PC.",Font=new Font(Font.FontFamily,8.5f),TextAlign=ContentAlignment.MiddleLeft};selection.Controls.Add(saved,0,3);
        diagnostic=Check("Diagnostics only — check activity without joining",true);selection.Controls.Add(diagnostic,0,4);
        menus=Check("I’m in Custom Games, outside a lobby, match or queue",false);selection.Controls.Add(menus,0,5);
        var actions=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2};actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,62));actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,38));
        watch=Button("Watch selected players",true);stop=Button("Stop following",false);watch.Enabled=stop.Enabled=false;actions.Controls.Add(watch,0,0);actions.Controls.Add(stop,1,0);selection.Controls.Add(actions,0,6);
        error=new Label{Dock=DockStyle.Fill,ForeColor=Color.Salmon,Font=new Font(Font.FontFamily,8.5f)};selection.Controls.Add(error,0,7);
        var watchedPanel=Card("People you’re watching");root.Controls.Add(watchedPanel,0,3);watched=List();watchedPanel.Controls.Add(watched);watched.BringToFront();
        passwordBar=new Panel{Dock=DockStyle.Top,Height=76,Visible=false};passwordTarget=new Label{Dock=DockStyle.Top,Height=27,ForeColor=gold};passwordBar.Controls.Add(passwordTarget);
        var passwordEntry=new TableLayoutPanel{Dock=DockStyle.Bottom,Height=37,ColumnCount=3};passwordEntry.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));passwordEntry.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,96));passwordEntry.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,74));
        password=Input(true);password.MaxLength=128;joinPassword=Button("Join lobby",true);var cancelPassword=Button("Cancel",false);passwordEntry.Controls.Add(password,0,0);passwordEntry.Controls.Add(joinPassword,1,0);passwordEntry.Controls.Add(cancelPassword,2,0);passwordBar.Controls.Add(passwordEntry);watchedPanel.Controls.Add(passwordBar);passwordBar.BringToFront();
        var logPanel=Card("Recent activity");root.Controls.Add(logPanel,0,4);activity=new TextBox{Dock=DockStyle.Fill,Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Vertical,BackColor=card,ForeColor=muted,BorderStyle=BorderStyle.None,Font=new Font("Consolas",8.5f)};logPanel.Controls.Add(activity);activity.BringToFront();
        var footer=new Panel{Dock=DockStyle.Fill};footer.Controls.Add(new Label{Text="Keep this app running. Close it to stop Follow.  ·  Saved friends stay on this PC.",Dock=DockStyle.Fill,ForeColor=muted,Font=new Font(Font.FontFamily,8)});
        report=Button("Diagnostics",false);report.Dock=DockStyle.Right;report.Width=115;footer.Controls.Add(report);root.Controls.Add(footer,0,5);
        add.Click+=async delegate {await AddTag();};tag.KeyDown+=async delegate(object sender,KeyEventArgs e){if(e.KeyCode==Keys.Enter){e.SuppressKeyPress=true;await AddTag();}};
        remove.Click+=async delegate {if(savedTags.SelectedItem==null)return;var chosen=Convert.ToString(savedTags.SelectedItem);await Configure(new {enabled=false,tags=CurrentTags().Where(t=>t!=chosen).ToArray()});};
        includeTeam.CheckedChanged+=async delegate {if(!updating)await Configure(new {enabled=false,includeTeam=includeTeam.Checked});};
        diagnostic.CheckedChanged+=async delegate {if(!updating)await Configure(new {enabled=false,diagnostic=diagnostic.Checked});};
        menus.CheckedChanged+=delegate {if(state!=null)Render(state);};
        watch.Click+=async delegate {await Configure(new {enabled=true,diagnostic=diagnostic.Checked,fromMenus=menus.Checked});};
        stop.Click+=async delegate {await Configure(new {enabled=false});};cancelPassword.Click+=async delegate {await Configure(new {enabled=false});};
        joinPassword.Click+=async delegate {string secret=password.Text;password.Clear();try{generation++;Render(await engine.Post("/api/password",new {password=secret}));}catch(Exception ex){error.Text=ex.Message;}finally{secret=null;}};
        report.Click+=async delegate {try{ShowReport(Json.Codec.Serialize(await engine.Get("/api/diagnostics")));}catch{error.Text="Diagnostics are not available yet.";}};
        Shown+=async delegate {try {await engine.Start(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"WarcraftTeamFollow"),false);await Poll();timer.Start();}catch(Exception ex){status.Text=ex.Message;mode.Text="Unable to start";}};
        timer.Interval=1500;timer.Tick+=async delegate {await Poll();};
        FormClosing+=async delegate(object sender,FormClosingEventArgs e){if(closing)return;e.Cancel=true;closing=true;timer.Stop();Enabled=false;await engine.Stop();Close();};
    }
    private Panel Card(string caption){var p=new Panel{Dock=DockStyle.Fill,BackColor=card,Padding=new Padding(12),Margin=new Padding(0,6,0,6)};p.Controls.Add(new Label{Text=caption,Dock=DockStyle.Top,Height=29,Font=new Font(Font.FontFamily,12),ForeColor=Color.WhiteSmoke});return p;}
    private Label Foot(string text,int height){return new Label{Text=text,Dock=DockStyle.Bottom,Height=height,ForeColor=muted,Font=new Font(Font.FontFamily,8.5f)};}
    private TextBox Input(bool secret){return new TextBox{Dock=DockStyle.Fill,BackColor=background,ForeColor=Color.WhiteSmoke,BorderStyle=BorderStyle.FixedSingle,UseSystemPasswordChar=secret,Margin=new Padding(0,4,6,4)};}
    private CheckBox Check(string text,bool value){return new CheckBox{Text=text,Checked=value,Dock=DockStyle.Fill,AutoSize=false,ForeColor=Color.WhiteSmoke};}
    private Button Button(string text,bool primary){return new Button{Text=text,Dock=DockStyle.Fill,FlatStyle=FlatStyle.Flat,BackColor=primary?gold:Color.FromArgb(39,49,62),ForeColor=primary?background:Color.WhiteSmoke,Margin=new Padding(0,2,6,2),Cursor=Cursors.Hand};}
    private ListView List(){var list=new ListView{Dock=DockStyle.Fill,View=View.Details,FullRowSelect=true,BackColor=card,ForeColor=Color.WhiteSmoke,BorderStyle=BorderStyle.None,HeaderStyle=ColumnHeaderStyle.Nonclickable};list.Columns.Add("Player",230);list.Columns.Add("Activity",220);return list;}
    private string[] CurrentTags(){return state==null?new string[0]:Json.Strings(state,"manualTags");}
    private async Task AddTag(){string value=tag.Text.Trim();if(value.Length==0)return;if(await Configure(new {enabled=false,tags=CurrentTags().Concat(new[]{value}).ToArray()}))tag.Clear();}
    private async Task<bool> Configure(object config){error.Text="";generation++;try{Render(await engine.Post("/api/config",config));return true;}catch(Exception ex){error.Text=ex.Message;return false;}}
    private async Task Poll(){
        if(polling||closing)return;polling=true;int expected=generation;
        try{var snapshot=await engine.Get("/api/state");failures=0;if(expected==generation&&!closing)Render(snapshot);}
        catch{failures++;if(failures>=3){mode.Text="Helper unavailable";watch.Enabled=false;stop.Enabled=false;}if(failures>=6){timer.Stop();engine.Dispose();status.Text="The local helper stopped responding. Close and reopen this app.";}}
        finally{polling=false;}
    }
    private void Render(Dictionary<string,object> snapshot){
        if(closing)return;state=snapshot;updating=true;
        try {
            bool connected=Json.Flag(state,"connected"),on=Json.Flag(state,"enabled"),paused=Json.Flag(state,"paused");
            status.Text=Json.Text(state,"status");mode.Text=!connected?"Waiting for Warcraft III":!on?"Game connected · Follow off":paused?"Follow on · paused":Json.Flag(state,"joinPending")?"Follow on · joining":"Continuous Follow on";
            mode.ForeColor=connected?gold:muted;includeTeam.Checked=Json.Flag(state,"includeTeam");diagnostic.Checked=Json.Flag(state,"diagnostic");
            var tags=Json.Strings(state,"manualTags");
            if(!savedTags.Items.Cast<object>().Select(Convert.ToString).SequenceEqual(tags)){savedTags.Items.Clear();savedTags.Items.AddRange(tags.Cast<object>().ToArray());}
            string saveError=Json.Text(state,"preferencesError");saved.Text=saveError.Length==0?"Friends and team choice save automatically on this PC.":saveError;saved.ForeColor=saveError.Length==0?muted:Color.Salmon;
            var players=Json.Rows(state,"team");Rows(team,players,"status",true);Rows(watched,Json.Rows(state,"watched"),"label",false);
            bool targets=(includeTeam.Checked&&players.Any(p=>!Json.Flag(p,"isSelf")))||tags.Length>0;
            watch.Enabled=connected&&targets&&menus.Checked&&!Json.Flag(state,"busy")&&!Json.Flag(state,"queued")&&!Json.Flag(state,"joinPending");stop.Enabled=on;
            watch.Text=on?"Refresh selected players":"Watch selected players";
            var request=Json.Value(state,"passwordRequest") as Dictionary<string,object>;
            passwordBar.Visible=request!=null;passwordTarget.Text=request==null?"":"Password requested for "+Json.Text(request,"lobby");if(request==null)password.Clear();
            var lines=Json.Rows(state,"log").AsEnumerable().Reverse().Take(7).Select(entry=>{DateTime date;string stamp=DateTime.TryParse(Json.Text(entry,"time"),out date)?date.ToLocalTime().ToString("HH:mm"):"";return stamp+"  "+Json.Text(entry,"message");});
            string log=string.Join(Environment.NewLine,lines);if(activity.Text!=log)activity.Text=log;
        }finally{updating=false;}
    }
    private void Rows(ListView list,List<Dictionary<string,object>> rows,string statusKey,bool self){
        string signature=string.Join("|",rows.Select(r=>Json.Text(r,"battleTag")+":"+Json.Text(r,statusKey)));
        if(Convert.ToString(list.Tag)==signature)return;list.Tag=signature;list.BeginUpdate();list.Items.Clear();
        foreach(var row in rows){var item=new ListViewItem(Json.Text(row,"battleTag")+(self&&Json.Flag(row,"isSelf")?" · you":""));item.SubItems.Add(Json.Text(row,statusKey));list.Items.Add(item);}list.EndUpdate();
    }
    private void ShowReport(string text){using(var dialog=new Form{Text="Local diagnostic report",Size=new Size(700,480),StartPosition=FormStartPosition.CenterParent,BackColor=background}){var box=new TextBox{Dock=DockStyle.Fill,Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Both,Text=text,BackColor=card,ForeColor=Color.WhiteSmoke};dialog.Controls.Add(box);var copy=new Button{Dock=DockStyle.Bottom,Height=38,Text="Copy report (contains no friend names)"};copy.Click+=delegate{Clipboard.SetText(text);};dialog.Controls.Add(copy);dialog.ShowDialog(this);}}
}

internal static class Program {
    [STAThread]public static int Main(string[] args){
        if(args.Length==2&&args[0]=="--self-test")return SelfTest(args[1]).GetAwaiter().GetResult();
        bool created;using(var mutex=new Mutex(true,"Local\\WarcraftTeamFollow.Desktop",out created)){
            if(!created){MessageBox.Show("Warcraft Team Follow is already running. Check its window on your taskbar.","Warcraft Team Follow");return 0;}
            Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new FollowWindow());return 0;
        }
    }
    private static async Task<int> SelfTest(string output){
        string resultFile=Path.GetFullPath(output),data=Path.Combine(Path.GetDirectoryName(resultFile),"desktop-test-"+Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(Path.GetDirectoryName(resultFile));
        using(var engine=new LocalEngine()){
            try {
                await engine.Start(data,true);var state=await engine.Get("/api/state");
                if(Json.Flag(state,"enabled")||!Json.Flag(state,"diagnostic"))throw new Exception();
                var tags=new[]{"FriendOne#1234","FriendTwo#2345","FriendThree#3456"};
                await engine.Post("/api/config",new {enabled=false,tags=tags,includeTeam=false});await engine.Stop();
                using(var restarted=new LocalEngine()){
                    await restarted.Start(data,true);state=await restarted.Get("/api/state");
                    if(!Json.Strings(state,"manualTags").SequenceEqual(tags)||Json.Flag(state,"includeTeam")||Json.Flag(state,"enabled"))throw new Exception();
                    var diagnostics=await restarted.Get("/api/diagnostics");
                    if(Json.Codec.Serialize(diagnostics).Contains("FriendOne"))throw new Exception();
                    await restarted.Stop();
                }
                File.WriteAllText(resultFile,Json.Codec.Serialize(new {success=true,checks=new[]{"bundled runtime starts","local control interface","three friends saved","restart restores friends","Follow starts off","diagnostics exclude names","no PowerShell discovery dependency"}}));return 0;
            }catch(Exception){File.WriteAllText(resultFile,"{\"success\":false,\"error\":\"Desktop package self-test failed\"}");return 1;}
        }
    }
}
