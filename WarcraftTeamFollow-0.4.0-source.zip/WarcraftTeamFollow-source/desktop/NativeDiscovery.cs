using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Web.Script.Serialization;

internal static class NativeDiscovery
{
    [StructLayout(LayoutKind.Sequential)] private struct TcpRow {
        public uint State, LocalAddress, LocalPort, RemoteAddress, RemotePort, ProcessId;
    }
    [StructLayout(LayoutKind.Sequential)] private struct TcpTable {
        public uint Count; public TcpRow First;
    }
    [DllImport("iphlpapi.dll", SetLastError=true)] private static extern uint GetExtendedTcpTable(IntPtr table,ref uint size,bool order,uint family,uint tableClass,uint reserved);
    private static List<int> Ports(int pid) {
        uint size=0;
        GetExtendedTcpTable(IntPtr.Zero,ref size,false,2,3,0);
        for(int attempt=0;attempt<3;attempt++) {
            IntPtr memory=Marshal.AllocHGlobal((int)size);
            try {
                uint result=GetExtendedTcpTable(memory,ref size,false,2,3,0);
                if(result==122)continue;
                if(result!=0)throw new InvalidOperationException("Cannot inspect the local game listener.");
                int count=Marshal.ReadInt32(memory),offset=(int)Marshal.OffsetOf(typeof(TcpTable),"First"),rowSize=Marshal.SizeOf(typeof(TcpRow));
                var ports=new List<int>();
                for(int i=0;i<count;i++) {
                    var row=(TcpRow)Marshal.PtrToStructure(IntPtr.Add(memory,offset+i*rowSize),typeof(TcpRow));
                    if(row.ProcessId!=(uint)pid || row.LocalAddress!=0x0100007F)continue;
                    int port=(ushort)IPAddress.NetworkToHostOrder((short)row.LocalPort);
                    if(port>=1024&&!ports.Contains(port))ports.Add(port);
                }
                ports.Sort();return ports;
            } finally {Marshal.FreeHGlobal(memory);}
        }
        throw new InvalidOperationException("The game listener changed. Try again.");
    }
    public static int Main() {
        try {
            var clients=Process.GetProcessesByName("Warcraft III");
            if(clients.Length!=1)throw new InvalidOperationException("Start exactly one Warcraft III client.");
            using(var game=clients[0]) {
                int menuPort=0;
                using(var handler=new HttpClientHandler {UseProxy=false})
                using(var http=new HttpClient(handler)) {
                    http.Timeout=TimeSpan.FromSeconds(2);
                    foreach(int port in Ports(game.Id)) {
                        try {
                            string html=http.GetStringAsync("http://127.0.0.1:"+port+"/webui/index.html").GetAwaiter().GetResult();
                            if(html.IndexOf("GlueManager",StringComparison.OrdinalIgnoreCase)>=0){menuPort=port;break;}
                        }catch(HttpRequestException){}catch(System.Threading.Tasks.TaskCanceledException){}
                    }
                }
                if(menuPort==0)throw new InvalidOperationException("Open Warcraft III's menus and wait for its local service.");
                string session=WarcraftMenuDiscovery.FindLocalMenuSession(game.Id);
                if(session==null)throw new InvalidOperationException("The game's local menu session is not available yet.");
                // Private child-process output, consumed in memory; never saved or shown in diagnostics.
                Console.WriteLine(new JavaScriptSerializer().Serialize(new {port=menuPort,session=session,version=game.MainModule.FileVersionInfo.FileVersion,pid=game.Id}));
                return 0;
            }
        }catch(Exception){Console.Error.WriteLine("The local Warcraft III menu is not available. Start the game normally and use the same Windows user.");return 1;}
    }
}
