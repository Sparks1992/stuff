# Windows desktop distribution

The release is a single self-extracting EXE with a native Windows Forms interface and bundled Node.js runtime. The ZIP contains that EXE, a quick-start README, and its checksum. Users need Windows 10/11 x64 and .NET Framework 4.8, but no separate Node.js or PowerShell 7 installation.

## Build

From the project root:

```powershell
.\desktop\Build-Windows.ps1
```

The build uses the installed x64 Node.js and the .NET Framework C# compiler. The checked-in `vendor/Node-LICENSE.txt` corresponds to Node.js v24.15.0; update the license when changing the bundled runtime. Output goes into `releases/WarcraftTeamFollow-0.4.0-win-x64/` and the ZIP beside it. Build intermediates go into `build/`.

`BundleLauncher.cs` verifies and extracts the embedded payload into a version-and-content-specific folder under `%LOCALAPPDATA%\WarcraftTeamFollow\app`. `DesktopApp.cs` runs the bundled helper, controls it through authenticated loopback requests, and presents team, saved-friend, watch, password, and diagnostic controls. `NativeDiscovery.cs` replaces the development PowerShell discovery dependency. Child-process lifetime is controlled by a Windows job and a parent-process watchdog.

## Verify

Run the packaged executable's isolated self-test:

```powershell
$report = Join-Path (Get-Location) 'build\desktop-self-test.json'
$exe = Join-Path (Get-Location) 'releases\WarcraftTeamFollow-0.4.0-win-x64\WarcraftTeamFollow.exe'
$test = Start-Process -FilePath $exe -ArgumentList @('--self-test', ('"' + $report + '"')) -WindowStyle Hidden -PassThru -Wait
Get-Content -LiteralPath $report
if ($test.ExitCode -ne 0) { throw 'Desktop self-test failed.' }
node --test tests/*.test.cjs
```

The self-test uses isolated temporary settings and disables game discovery. It verifies the bundled runtime, control interface, saving three sample friends, restoration after restart, Follow starting off, diagnostic redaction, and operation without PowerShell discovery. It does not join a real lobby. Separately check the native interface and connection to a normally launched Warcraft III client.

## Packaging privacy

The build explicitly copies the three companion modules, three web assets, native app and discovery executables, app configuration, bundled Node runtime and license, and README. It does not copy project settings, runtime records, research captures, or game files. Personal settings live outside the extracted application folder, under `%LOCALAPPDATA%\WarcraftTeamFollow\settings`.

The executable is unsigned. Closing the interface stops its backend; minimizing keeps it running. Following is not automatically enabled on startup. The underlying follow behavior has a verified live open-lobby join; a complete live match pause/resume cycle, team selection, and protected-lobby joins still need separate live verification.
