'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const create = require('../webui/follow-friend.js');
function fixture() {
  let time = 1000;
  const commands = [];
  const app = create({ localStorage: { setItem() {} } }, {
    manual: true, now: () => time,
    send: (message, payload) => { commands.push({ message, payload }); return true; }
  });
  const receive = (messageType, payload) => app.receive({ messageType, payload });
  const friend = (game = 'Friends lobby', tag = 'Friend#1234') => receive('FriendsFriendUpdated', {
    data: { friend: { battleTag: tag, localRichPresenceAttributes: [{ key: 'currentGameName', value: game }] } }
  });
  const list = (games = [{ id: 25, name: 'Friends lobby', mapFile: 'Maps/Test.w3x' }]) => receive('GameList', { games });
  const joins = () => commands.filter(c => c.message === 'JoinGame');
  app.setConnected(true);
  app.configure({ target: 'Friend#1234', diagnostic: false, enabled: true });
  return { app, receive, friend, list, joins, commands, advance: ms => { time += ms; },
    browser: () => receive('SetGlueScreen', { screen: 'CUSTOM_LOBBIES' }) };
}
test('joins only an exact fresh lobby for the selected full BattleTag', () => {
  const f = fixture(); f.browser(); f.friend(); f.list();
  assert.deepEqual(f.joins(), [{ message: 'JoinGame', payload: { gameId: 25, password: '', mapFile: 'Maps/Test.w3x' } }]);
  f.friend(); f.list(); f.app.tick(); assert.equal(f.joins().length, 1);
});
test('diagnostic mode reports the match without joining, then can be switched to live', () => {
  const f = fixture(); f.app.configure({ diagnostic: true }); f.browser(); f.friend(); f.list();
  assert.equal(f.joins().length, 0); assert.match(f.app.snapshot().status, /Ready:/);
  f.app.configure({ diagnostic: false }); assert.equal(f.joins().length, 1);
});
test('unknown, playing, loading, score and existing lobby states never authorize a join', () => {
  for (const screen of ['', 'MAIN_MENU', 'GAME_LOBBY', 'CUSTOM_GAME_LOBBY', 'LOADING_SCREEN', 'DISABLED_SCREEN', 'OUT_OF_MENUS', 'SCORE_SCREEN']) {
    const f = fixture(); f.receive('SetGlueScreen', { screen }); f.friend(); f.list(); f.app.tick();
    assert.equal(f.joins().length, 0, screen);
  }
});
test('lobby setup blocks joins even without a subsequent screen event', () => {
  const f = fixture(); f.browser(); f.receive('GameLobbySetup', {}); f.friend(); f.list();
  assert.equal(f.joins().length, 0);
});
test('stale presence, wrong BattleTag and similar names cannot join', () => {
  const f = fixture(); f.browser(); f.friend('Friends lobby', 'Friend#9999'); f.list();
  assert.equal(f.joins().length, 0);
  const stale = fixture(); stale.browser(); stale.friend(); stale.advance(31000); stale.list();
  assert.equal(stale.joins().length, 0);
  const similar = fixture(); similar.browser(); similar.friend('Friends lobby 2'); similar.list();
  assert.equal(similar.joins().length, 0);
});
test('ambiguous or full lobbies are not joined', () => {
  const f = fixture(); f.browser(); f.friend();
  const g = { id: 1, name: 'Friends lobby', mapFile: 'test' };
  f.list([g, { ...g, id: 2 }]); assert.equal(f.joins().length, 0);
  f.list([{ ...g, currentPlayers: 12, maxPlayers: 12 }]); assert.equal(f.joins().length, 0);
});
test('removed and cleared listings cannot be used for joining', () => {
  for (const messageType of ['GameListClear', 'GameListRemove']) {
    const f = fixture(); f.browser(); f.list(); f.receive(messageType, { game: { id: 25 } }); f.friend();
    assert.equal(f.joins().length, 0);
  }
});
test('logout and disconnect stop following and discard cached data', () => {
  for (const reset of [f => f.receive('LoggedOut', {}), f => f.app.setConnected(false)]) {
    const f = fixture(); f.browser(); f.list(); reset(f); f.friend(); f.app.tick();
    assert.equal(f.app.snapshot().enabled, false); assert.equal(f.joins().length, 0);
  }
});
test('requests are rate limited and join timeouts do not retry automatically', () => {
  const f = fixture(); f.browser(); f.app.tick(); f.app.tick();
  assert.equal(f.commands.filter(c => c.message === 'GetGameList').length, 1);
  f.friend(); f.list(); f.advance(16000); f.app.tick();
  assert.equal(f.app.snapshot().pending, null); f.friend(); f.list(); assert.equal(f.joins().length, 1);
});
test('screen change discards stale listings before returning to browser', () => {
  const f = fixture(); f.browser(); f.list(); f.receive('SetGlueScreen', { screen: 'LOADING_SCREEN' });
  f.browser(); f.friend(); assert.equal(f.joins().length, 0); f.list(); assert.equal(f.joins().length, 1);
});
test('invalid payloads and tags do not produce joins; reports omit player information', () => {
  const f = fixture(); f.app.receive('invalid JSON'); f.app.receive(null); f.browser(); f.friend();
  f.list([{ id: '25', name: 'Friends lobby', mapFile: 'test' }]); assert.equal(f.joins().length, 0);
  assert.throws(() => f.app.configure({ target: 'Friend' }), /full BattleTag/);
  assert.doesNotMatch(f.app.exportDiagnostics(), /Friend#1234|Friends lobby|Maps\/Test|webui-socket/);
});
test('socket observation preserves the native onmessage and ignores unrelated connections', () => {
  const f = fixture(); const handlers = {};
  const original = () => {};
  const socket = { url: 'ws://127.0.0.1/webui-socket/session', readyState: 1, onmessage: original,
    addEventListener: (name, fn) => { handlers[name] = fn; } };
  f.app.attach(socket); assert.equal(socket.onmessage, original);
  handlers.message({ data: JSON.stringify({ messageType: 'GameVersion', payload: { gameVersion: '3.0.1' } }) });
  assert.equal(f.app.snapshot().gameVersion, '3.0.1');
  f.app.attach({ url: 'ws://127.0.0.1:8888', addEventListener: () => assert.fail('unrelated socket') });
  handlers.close(); assert.equal(f.app.snapshot().enabled, false);
});
