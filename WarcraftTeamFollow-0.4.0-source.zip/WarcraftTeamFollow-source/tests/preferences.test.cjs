'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {loadPreferences,savePreferences}=require('../companion/preferences.cjs');
const {TeamFollow}=require('../companion/team-follow.cjs');
function setup(t){const root=path.resolve(__dirname,'..','runtime');fs.mkdirSync(root,{recursive:true});const dir=fs.mkdtempSync(path.join(root,'prefs-test-'));t.after(()=>{if(!path.resolve(dir).startsWith(root+path.sep))throw new Error('Unexpected test directory');fs.rmSync(dir,{recursive:true,force:true});});return path.join(dir,'settings','friends.json');}
test('three friends and team choice survive a fresh helper instance',t=>{
  const file=setup(t),tags=['One#1234','Two#2345','Three#3456'];
  savePreferences(file,{tags,includeTeam:false,enabled:true,diagnostic:false,session:'not-to-be-saved'});
  const fresh=new TeamFollow();fresh.configure({...loadPreferences(file),enabled:false});
  assert.deepEqual(fresh.manualTags,tags);assert.equal(fresh.includeTeam,false);
  assert.equal(fresh.enabled,false);assert.equal(fresh.diagnostic,true);
  assert.deepEqual(Object.keys(JSON.parse(fs.readFileSync(file,'utf8'))).sort(),['includeTeam','tags']);
});
test('removing friends is saved and updates leave no temporary files',t=>{
  const file=setup(t);savePreferences(file,{tags:['One#1234'],includeTeam:true});
  savePreferences(file,{tags:[],includeTeam:false});assert.deepEqual(loadPreferences(file),{tags:[],includeTeam:false});
  assert.deepEqual(fs.readdirSync(path.dirname(file)),['friends.json']);
});
test('missing settings use defaults; malformed files fail without overwriting',t=>{
  const file=setup(t);assert.deepEqual(loadPreferences(file),{tags:[],includeTeam:true});
  fs.mkdirSync(path.dirname(file));fs.writeFileSync(file,'not json');
  assert.throws(()=>loadPreferences(file),/could not be loaded/);assert.equal(fs.readFileSync(file,'utf8'),'not json');
});
test('invalid data cannot replace previously saved friends; duplicates normalize',t=>{
  const file=setup(t);savePreferences(file,{tags:[' One#1234 ','one#1234'],includeTeam:true});
  assert.deepEqual(loadPreferences(file).tags,['One#1234']);
  assert.throws(()=>savePreferences(file,{tags:['bad'],includeTeam:true}),/Invalid/);
  assert.deepEqual(loadPreferences(file).tags,['One#1234']);
});
