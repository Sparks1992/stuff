'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {TeamFollow}=require('../companion/team-follow.cjs');
function fixture(){
  let time=1000; const commands=[];
  const engine=new TeamFollow({now:()=>time,send:(message,payload)=>{commands.push({message,payload});return true;}});
  const receive=(messageType,payload={})=>engine.receive({messageType,payload});
  const member=(battleTag='Friend#1234')=>({battleTag,isSelf:false,isFriend:true,auroraId:42});
  const roster=(members=[member()])=>receive('TeamsInformation',{message:{partyMembers:[{battleTag:'Self#1111',isSelf:true},...members],memberCount:members.length+1}});
  const friend=(overrides={})=>({battleTag:'Friend#1234',accountId:42,isOnline:true,isFriend:true,currentProgram:'W3',localRichPresenceAttributes:[{key:'currentGameState',value:'open'}],...overrides});
  const presence=(overrides={})=>receive('FriendsFriendData',{data:{friends:[friend(overrides)]}});
  const arm=(diagnostic=false)=>engine.configure({enabled:true,diagnostic,fromMenus:true});
  const joins=()=>commands.filter(c=>c.message==='JoinFriendGameLobby');
  engine.connection(true,'3.0.1.24371');roster();
  return {engine,receive,member,roster,friend,presence,arm,joins,commands,advance:ms=>{time+=ms;}};
}
test('reads roster from the live-build shape and excludes self when arming',()=>{
  const f=fixture();f.arm(true);assert.equal(f.engine.snapshot().watched.length,1);
  assert.equal(f.engine.snapshot().watched[0].battleTag,'Friend#1234');
});
test('joins an open friend lobby using native account ID with no lobby name',()=>{
  const f=fixture();f.arm();f.presence();
  assert.deepEqual(f.commands.slice(-3),[
    {message:'RequestCancelTeamInvitations',payload:{}},
    {message:'TeamLeave',payload:{}},
    {message:'JoinFriendGameLobby',payload:{auroraId:42}}
  ]);assert.equal(f.engine.enabled,true);assert.equal(f.engine.lastJoin.confirmed,false);
});
test('diagnostics never leaves a team or joins',()=>{
  const f=fixture();f.arm(true);f.presence();f.presence();
  assert.equal(f.joins().length,0);assert.match(f.engine.status,/Diagnostics mode prevented/);
  assert.ok(f.commands.every(c=>c.message==='FriendsGetFriends'));
});
test('switching from diagnostics to live requires a new explicit arm',()=>{
  const f=fixture();f.arm(true);f.presence();f.engine.configure({diagnostic:false});
  assert.equal(f.engine.enabled,false);assert.equal(f.joins().length,0);
});
test('does not act on cached activity from before arming',()=>{
  const f=fixture();f.presence();f.arm();assert.equal(f.joins().length,0);f.presence();assert.equal(f.joins().length,1);
});
test('follows remembered members after the live team disbands',()=>{
  const f=fixture();f.arm();f.receive('TeamsDisbanded');f.presence();
  assert.equal(f.joins().length,1);assert.equal(f.engine.snapshot().watched.length,1);
  assert.ok(!f.commands.some(c=>c.message==='TeamLeave'));
});
test('does not follow outsiders or newly added members without rearming',()=>{
  const f=fixture();f.arm();f.roster([f.member('Other#2222')]);f.presence({battleTag:'Other#2222'});assert.equal(f.joins().length,0);
});
test('chooses deterministically if two team members are joinable at once',()=>{
  const f=fixture();f.roster([f.member(),f.member('Other#2222')]);f.arm();
  f.receive('FriendsFriendData',{data:{friends:[f.friend({battleTag:'Other#2222',accountId:77}),f.friend()]}});
  assert.deepEqual(f.joins().map(c=>c.payload.auroraId),[42]);
});
test('never chases a second teammate after a join attempt',()=>{
  const f=fixture();f.arm();f.presence();f.presence();f.engine.tick();assert.equal(f.joins().length,1);
  assert.throws(()=>f.arm(),/pending/);
});
test('ignores offline, nonfriend, other-game, closed and malformed activity',()=>{
  const variants=[{isOnline:false},{isFriend:false},{currentProgram:'WoW'},{accountId:null},{accountId:0},{accountId:'bad'},
    {localRichPresenceAttributes:[{key:'currentGameState',value:'closed'}]},{localRichPresenceAttributes:null}];
  for(const variant of variants){const f=fixture();f.arm();f.presence(variant);assert.equal(f.joins().length,0,JSON.stringify(variant));}
});
test('queue, lobby, loading and gameplay events pause joining without switching Follow off',()=>{
  const events=[['QueueEntered',{}],['GameLobbySetup',{}],['GameFound',{}],['PauseUI',{}],
    ['SetGlueScreen',{screen:'LOADING_SCREEN'}],['IsGameUIActive',{isActive:'true'}]];
  for(const [type,payload] of events){const f=fixture();f.arm();f.receive(type,payload);f.presence();assert.equal(f.joins().length,0,type);assert.equal(f.engine.enabled,true);assert.equal(f.engine.snapshot().paused,true);}
});
test('joining requires a team, fresh roster, known build, connection and menu acknowledgement',()=>{
  const f=fixture();assert.throws(()=>f.engine.configure({enabled:true}),/menus/);
  f.roster([]);assert.throws(()=>f.arm(),/Invite/);
  f.roster();f.advance(21000);assert.throws(()=>f.arm(),/fresh/);
  f.engine.connection(false);assert.throws(()=>f.arm(),/Start Warcraft/);
  f.engine.connection(true,'future-build');f.roster();assert.throws(()=>f.arm(),/not been verified/);
});
test('stale friend activity is not joinable',()=>{
  const f=fixture();f.arm(true);f.presence();f.advance(21000);assert.equal(f.engine.snapshot().watched[0].open,false);
});
test('disconnect forgets the roster and disarms',()=>{
  const f=fixture();f.arm();f.engine.connection(false);f.presence();assert.equal(f.joins().length,0);assert.equal(f.engine.watched.length,0);
});
test('timeouts never retry and reports exclude player names and IDs',()=>{
  const f=fixture();f.arm();f.presence();f.advance(16000);f.engine.tick();f.presence();assert.equal(f.joins().length,1);
  assert.equal(f.engine.pending,null);assert.doesNotMatch(JSON.stringify(f.engine.diagnostics()),/Friend#|Self#|auroraId|accountId/);
});
test('errors stop the sequence without issuing the final join',()=>{
  const f=fixture();f.engine.send=(message,payload)=>{f.commands.push({message,payload});return message!=='TeamLeave';};
  f.arm();f.presence();assert.equal(f.joins().length,0);assert.equal(f.engine.enabled,true);
});
test('malformed events and mismatched tags never authorize joining',()=>{
  const f=fixture();f.arm();f.engine.receive(null);f.receive('TeamsInformation',{message:{partyMembers:null}});
  f.presence({battleTag:'Friend#9999'});f.receive('FriendsFriendUpdated',{data:{}});assert.equal(f.joins().length,0);
});
test('manual friend can be followed without a team or team-roster freshness',()=>{
  const f=fixture();f.roster([]);f.advance(25000);f.presence();
  f.engine.configure({tags:['friend#1234'],includeTeam:false});f.arm();
  assert.equal(f.engine.watched.length,1);assert.equal(f.joins().length,0);
  f.presence();assert.equal(f.joins().length,1);assert.ok(!f.commands.some(c=>c.message==='TeamLeave'));
});
test('manual tags and current teammates are merged without duplicates',()=>{
  const f=fixture();f.presence();f.engine.configure({tags:['friend#1234','Friend#1234']});f.arm(true);
  assert.equal(f.engine.manualTags.length,1);assert.equal(f.engine.watched.length,1);
});
test('invalid, unknown, self and nonfriend tags cannot arm following',()=>{
  const f=fixture();assert.throws(()=>f.engine.configure({tags:['Friend']}),/full BattleTag/);
  assert.throws(()=>f.engine.configure({tags:'Friend#1234'}),/12 friend/);
  assert.throws(()=>f.engine.configure({tags:Array(13).fill('Friend#1234')}),/12 friend/);
  f.engine.configure({tags:['Unknown#1234'],includeTeam:false});assert.throws(()=>f.arm(),/friend activity/);
  f.engine.configure({tags:['Self#1111']});assert.throws(()=>f.arm(),/your own/);
  f.presence({isFriend:false});f.engine.configure({tags:['Friend#1234']});assert.throws(()=>f.arm(),/friends list/);
});
test('changing manual selection stops following; reconnect keeps choices but never arms',()=>{
  const f=fixture();f.arm(true);f.engine.configure({tags:['Friend#1234'],includeTeam:false});
  assert.equal(f.engine.enabled,false);f.engine.connection(false);
  assert.deepEqual(f.engine.manualTags,['Friend#1234']);assert.equal(f.engine.includeTeam,false);assert.equal(f.engine.enabled,false);
  assert.doesNotMatch(JSON.stringify(f.engine.diagnostics()),/Friend#1234/);
});
test('open-lobby friend join completes the native password preflight once with an empty password',()=>{
  const f=fixture();f.arm();f.presence({localRichPresenceAttributes:[{key:'currentGameState',value:'open'},{key:'currentGameName',value:'Open lobby'}]});
  f.receive('RequestForPassword',{message:{matchJoinGameByNameText:'Open lobby'}});
  assert.deepEqual(f.commands.at(-1),{message:'JoinGameByGameName',payload:{gameName:'Open lobby',gamePass:''}});
  assert.equal(f.engine.enabled,true);assert.equal(f.engine.passwordRequest,null);
  f.receive('GameLobbySetup',{lobbyName:'Open lobby',players:[{isSelf:true,slotStatus:2}]});
  assert.equal(f.engine.lastJoin.confirmed,true);assert.match(f.engine.status,/Joined/);
});
test('repeated password request prompts instead of looping; submitted password never enters state or logs',()=>{
  const f=fixture();f.arm();f.presence();const event={message:{matchJoinGameByNameText:'Protected'}};
  f.receive('RequestForPassword',event);f.receive('RequestForPassword',event);
  assert.equal(f.commands.filter(c=>c.message==='JoinGameByGameName').length,1);
  assert.equal(f.engine.snapshot().passwordRequest.lobby,'Protected');
  f.engine.submitPassword('local-test-secret');
  assert.deepEqual(f.commands.at(-1),{message:'JoinGameByGameName',payload:{gameName:'Protected',gamePass:'local-test-secret'}});
  assert.doesNotMatch(JSON.stringify(f.engine.snapshot()),/local-test-secret/);
  assert.doesNotMatch(JSON.stringify(f.engine.diagnostics()),/local-test-secret/);
});
test('unsolicited, mismatched and expired lobby confirmations cannot join',()=>{
  const f=fixture();f.receive('RequestForPassword',{message:{matchJoinGameByNameText:'Other'}});
  assert.equal(f.commands.filter(c=>c.message==='JoinGameByGameName').length,0);
  f.arm();f.presence({localRichPresenceAttributes:[{key:'currentGameState',value:'open'},{key:'currentGameName',value:'Wanted'}]});
  f.receive('RequestForPassword',{message:{matchJoinGameByNameText:'Other'}});
  assert.equal(f.commands.filter(c=>c.message==='JoinGameByGameName').length,0);
  const late=fixture();late.arm();late.presence();late.advance(16000);late.engine.tick();
  late.receive('RequestForPassword',{message:{matchJoinGameByNameText:'Late'}});
  assert.equal(late.commands.filter(c=>c.message==='JoinGameByGameName').length,0);
});
test('stopping, diagnostics or queueing prevents password follow-up commands',()=>{
  for(const stop of [f=>f.engine.configure({enabled:false}),f=>f.receive('QueueEntered'),f=>f.engine.configure({diagnostic:true})]){
    const f=fixture();f.arm();f.presence();stop(f);f.receive('RequestForPassword',{message:{matchJoinGameByNameText:'Open'}});
    assert.equal(f.commands.filter(c=>c.message==='JoinGameByGameName').length,0);
  }
});
test('password prompt expires and cannot be used after a disconnect',()=>{
  const f=fixture();f.arm();f.presence();const event={message:{matchJoinGameByNameText:'Open'}};
  f.receive('RequestForPassword',event);f.receive('RequestForPassword',event);f.advance(120001);f.engine.tick();
  assert.equal(f.engine.passwordRequest,null);assert.throws(()=>f.engine.submitPassword('test'),/expired/);
  f.engine.connection(false);assert.throws(()=>f.engine.submitPassword('test'),/expired/);
});
test('continuous Follow resumes after a lobby, a match and return to Custom Games',()=>{
  const f=fixture();f.arm();f.presence();assert.equal(f.joins().length,1);
  f.receive('GameLobbySetup',{players:[{isSelf:true,slotStatus:2}],lobbyName:'First'});
  assert.equal(f.engine.enabled,true);assert.equal(f.engine.snapshot().paused,true);
  const next={localRichPresenceAttributes:[{key:'currentGameState',value:'open'},{key:'currentGameName',value:'Next lobby'}]};
  f.presence(next);f.advance(11000);f.engine.tick();assert.equal(f.joins().length,1);
  f.receive('IsGameUIActive',{isActive:'true'});f.receive('MultiplayerGameLeave');
  f.receive('GameList',{games:[]});f.advance(3000);f.engine.tick();assert.equal(f.joins().length,1);assert.equal(f.engine.inMatch,true);
  f.receive('ExitedGame');f.advance(3000);f.receive('GameList',{games:[]});
  assert.equal(f.engine.busy,false);assert.equal(f.engine.enabled,true);assert.equal(f.engine.friends.size,0);
  f.presence(next);assert.equal(f.joins().length,2);assert.equal(f.engine.enabled,true);
});
test('leaving the same lobby does not trap the user in immediate rejoins',()=>{
  const f=fixture();f.arm();f.presence();f.receive('GameLobbySetup',{});f.receive('MultiplayerGameLeave');
  f.advance(11000);f.receive('GameList',{games:[]});f.presence();f.engine.tick();assert.equal(f.joins().length,1);
  f.presence({localRichPresenceAttributes:[{key:'currentGameState',value:'playing'}]});
  f.presence();assert.equal(f.joins().length,2);
});
test('a return signal alone cannot resume during match loading or without menu evidence',()=>{
  const f=fixture();f.arm();f.receive('GameFound');f.receive('MultiplayerGameLeave');f.advance(3000);
  f.receive('GameList',{games:[]});f.presence();assert.equal(f.joins().length,0);
  f.receive('ExitedGame');f.advance(3000);f.presence();f.engine.tick();assert.equal(f.joins().length,0);
  f.receive('GameList',{games:[]});assert.equal(f.engine.friends.size,0);f.presence();assert.equal(f.joins().length,1);
});
test('manual Stop overrides automatic resume',()=>{
  const f=fixture();f.arm();f.receive('GameFound');f.engine.configure({enabled:false});f.receive('ExitedGame');
  f.advance(3000);f.receive('GameList',{games:[]});f.presence();assert.equal(f.joins().length,0);assert.equal(f.engine.enabled,false);
});
test('failed and timed-out attempts wait for a new lobby and respect the cooldown',()=>{
  const f=fixture();f.arm();f.presence();f.receive('GameSearchFailedToJoinGame');f.advance(11000);f.presence();
  assert.equal(f.joins().length,1);assert.equal(f.engine.enabled,true);
  f.presence({localRichPresenceAttributes:[{key:'currentGameState',value:'open'},{key:'currentGameName',value:'A new lobby'}]});
  assert.equal(f.joins().length,2);
});
test('repeated lobby updates confirm once and never join another friend while inside',()=>{
  const f=fixture();f.arm();f.presence();
  const lobby={lobbyName:'Lobby',players:[{isSelf:true,slotStatus:2}]};
  f.receive('GameLobbySetup',lobby);f.receive('GameLobbySetup',lobby);
  assert.equal(f.engine.log.filter(e=>e.message.startsWith('Joined ')).length,1);
  assert.equal(f.joins().length,1);assert.equal(f.engine.enabled,true);
});
