/* Warcraft Follow 0.1.0. Original implementation; no external scripts or services. */
(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) module.exports = factory;
  else if (!root.WarcraftFollow) root.WarcraftFollow = factory(root);
})(typeof window !== 'undefined' ? window : globalThis, function (host, options) {
  'use strict';
  options = options || {};
  var now = options.now || Date.now;
  var send = options.send || sendNative;
  var observers = [], sockets = [], activeSocket = null;
  var friends = new Map(), games = new Map(), attempts = new Set();
  var logs = [], events = {}, timer, panel;
  var state = {
    version: '0.1.0', target: '', enabled: false, diagnostic: true,
    screen: '', connected: false, gameVersion: '',
    status: 'Waiting for the game menu connection.', pending: null
  };
  var lastFriendsRequest = -Infinity, lastGamesRequest = -Infinity;
  var targetSeenAt = -Infinity, gamesSeenAt = -Infinity;
  var blockedScreens = new Set(['GAME_LOBBY', 'CUSTOM_GAME_LOBBY', 'LOADING_SCREEN',
    'DISABLED_SCREEN', 'OUT_OF_MENUS', 'SCORE_SCREEN']);
  // A lobby list alone must never authorize joining during a match.
  var safeScreens = new Set(['CUSTOM_LOBBIES']);
  function notify() { observers.forEach(function (fn) { fn(snapshot()); }); }
  function note(message) {
    logs.push({ time: new Date(now()).toISOString(), message: message });
    if (logs.length > 80) logs.shift();
    state.status = message; notify();
  }
  function snapshot() {
    return Object.assign({}, state, {
      friends: Array.from(friends.values()).map(function (f) {
        return { battleTag: f.battleTag, game: gameName(f) };
      }), gameCount: games.size, events: Object.assign({}, events), logs: logs.slice()
    });
  }
  function gameName(friend) {
    var attrs = friend && friend.localRichPresenceAttributes;
    var item = Array.isArray(attrs) && attrs.find(function (a) { return a.key === 'currentGameName'; });
    return item && typeof item.value === 'string' ? item.value : '';
  }
  function key(tag) { return String(tag || '').trim().toLowerCase(); }
  function sendNative(message, payload) {
    if (!activeSocket || activeSocket.readyState !== 1) return false;
    activeSocket.send(JSON.stringify({ message: message, payload: payload || {} }));
    return true;
  }
  function command(message, payload) {
    try { return send(message, payload || {}) !== false; }
    catch (_) { note('The game command failed. Follow has been paused.'); state.enabled = false; return false; }
  }
  function resetSession() {
    friends.clear(); games.clear(); attempts.clear();
    targetSeenAt = gamesSeenAt = -Infinity;
    state.pending = null; state.screen = ''; state.enabled = false;
    lastFriendsRequest = lastGamesRequest = -Infinity;
  }
  function updateFriend(friend) {
    if (!friend || typeof friend.battleTag !== 'string') return;
    friends.set(key(friend.battleTag), friend);
    if (key(friend.battleTag) === key(state.target)) targetSeenAt = now();
  }
  function receive(input) {
    var event;
    try { event = typeof input === 'string' ? JSON.parse(input) : input; }
    catch (_) { return; }
    if (!event || typeof event.messageType !== 'string') return;
    var type = event.messageType, p = event.payload || {};
    if (Object.keys(events).length < 80 || events[type]) events[type] = (events[type] || 0) + 1;
    switch (type) {
      case 'SetGlueScreen':
        state.screen = typeof p.screen === 'string' ? p.screen : '';
        if (!safeScreens.has(state.screen)) { games.clear(); gamesSeenAt = -Infinity; }
        if (state.screen === 'LOGIN_DOORS') {
          resetSession(); note('Signed out. Follow is off.');
        } else if (blockedScreens.has(state.screen)) {
          state.pending = null;
          note('Follow is waiting. Open Custom Games after your match.');
        } else note('Menu detected: ' + state.screen);
        break;
      case 'GameVersion': state.gameVersion = String(p.gameVersion || ''); break;
      case 'LoggedOut': resetSession(); note('Signed out. Follow is off.'); break;
      case 'FriendsFriendData':
        if (p.data && Array.isArray(p.data.friends)) {
          friends.clear(); targetSeenAt = -Infinity;
          p.data.friends.forEach(updateFriend);
        }
        break;
      case 'FriendsFriendUpdated': updateFriend(p.data && p.data.friend); break;
      case 'FriendsFriendRemoved':
        // Removal payloads vary. Discard cached presence until a fresh snapshot arrives.
        friends.clear(); targetSeenAt = -Infinity; break;
      case 'GameList':
        if (safeScreens.has(state.screen) && Array.isArray(p.games)) {
          games.clear();
          p.games.forEach(function (g) {
            if (g && Number.isInteger(g.id) && typeof g.name === 'string' && typeof g.mapFile === 'string')
              games.set(g.id, Object.assign({}, g));
          });
          gamesSeenAt = now();
        }
        break;
      case 'GameListClear': games.clear(); gamesSeenAt = -Infinity; break;
      case 'GameListRemove': if (p.game) games.delete(p.game.id); break;
      case 'GameListUpdate':
        if (p.game && games.has(p.game.id)) Object.assign(games.get(p.game.id), p.game);
        break;
      case 'GameLobbySetup':
        // Being in any lobby blocks further automatic joins even if a screen event is missing.
        state.screen = 'GAME_LOBBY'; state.pending = null;
        games.clear(); gamesSeenAt = -Infinity;
        note('Lobby detected. Follow is waiting until you return to Custom Games.');
        break;
    }
    evaluate(); notify();
  }
  function evaluate() {
    if (!state.enabled || !state.connected || !safeScreens.has(state.screen) || state.pending) return;
    var friend = friends.get(key(state.target));
    if (!friend || now() - targetSeenAt > 30000 || now() - gamesSeenAt > 15000) return;
    var name = gameName(friend);
    if (!name) return;
    var matches = Array.from(games.values()).filter(function (g) { return g.name === name; });
    if (matches.length !== 1) return;
    var game = matches[0];
    if (Number.isFinite(game.currentPlayers) && Number.isFinite(game.maxPlayers)
        && game.currentPlayers >= game.maxPlayers) return;
    var attemptKey = key(state.target) + ':' + game.id;
    if (attempts.has(attemptKey)) return;
    // Exactly one attempt per lobby ID per session. Manual retry is explicit.
    attempts.add(attemptKey);
    if (state.diagnostic) {
      note('Ready: found ' + name + '. Diagnostics mode has prevented joining.');
      return;
    }
    state.pending = { gameId: game.id, started: now() };
    if (command('JoinGame', { gameId: game.id, password: '', mapFile: game.mapFile }))
      note('Requested to join ' + name + '. Waiting for lobby confirmation.');
    else state.pending = null;
  }
  function tick() {
    if (!state.connected) return;
    if (state.pending && now() - state.pending.started > 15000) {
      state.pending = null;
      note('Join was not confirmed. Use Retry after checking the lobby.');
    }
    if (!state.enabled || !safeScreens.has(state.screen)) return;
    if (now() - lastFriendsRequest >= 10000) {
      lastFriendsRequest = now(); command('FriendsGetFriends');
    }
    if (now() - lastGamesRequest >= 5000) {
      lastGamesRequest = now(); command('GetGameList');
    }
    evaluate();
  }
  function configure(config) {
    if ('target' in config) {
      var target = String(config.target || '').trim();
      if (target && !/^[^\s#]{2,32}#\d{3,12}$/.test(target)) throw new Error('Enter the full BattleTag, such as Friend#1234.');
      if (key(target) !== key(state.target)) { targetSeenAt = -Infinity; attempts.clear(); }
      state.target = target;
    }
    if ('diagnostic' in config) {
      var changed = state.diagnostic !== Boolean(config.diagnostic);
      state.diagnostic = Boolean(config.diagnostic);
      if (changed) attempts.clear();
    }
    if ('enabled' in config) {
      if (config.enabled && !state.target) throw new Error('Enter a BattleTag first.');
      state.enabled = Boolean(config.enabled);
    }
    try { host.localStorage.setItem('warcraft-follow-target', state.target); } catch (_) { /* optional */ }
    note(state.enabled ? 'Follow enabled. Open Custom Games and wait for your friend.' : 'Follow is off.');
    tick(); return snapshot();
  }
  function attach(socket) {
    if (!socket || sockets.indexOf(socket) !== -1 || typeof socket.addEventListener !== 'function') return;
    // Only the game's own menu socket. Never attach to another mod's service.
    if (!/\/webui-socket\//.test(String(socket.url || ''))) return;
    sockets.push(socket);
    var connected = function () {
      if (activeSocket && activeSocket !== socket && activeSocket.readyState === 1) return;
      activeSocket = socket; state.connected = true;
      note('Menu connection found. Waiting for friend and screen events.');
    };
    socket.addEventListener('open', connected);
    socket.addEventListener('message', function (e) {
      if (activeSocket === socket && typeof e.data === 'string') receive(e.data);
    });
    socket.addEventListener('close', function () {
      if (activeSocket !== socket) return;
      activeSocket = null; state.connected = false; resetSession();
      note('Menu disconnected. Follow is off.');
    });
    if (socket.readyState === 1) connected();
  }
  function installHook() {
    if (typeof host.WebSocket === 'function' && typeof Proxy === 'function') {
      var Native = host.WebSocket;
      host.WebSocket = new Proxy(Native, {
        construct: function (Target, args, NewTarget) {
          var socket = Reflect.construct(Target, args, NewTarget);
          attach(socket); return socket;
        }
      });
    }
    if (Array.isArray(host.sockets)) host.sockets.forEach(attach);
  }
  function exportDiagnostics() {
    // Deliberately exclude BattleTags, lobby names, payloads and websocket URLs.
    return JSON.stringify({ version: state.version, gameVersion: state.gameVersion,
      connected: state.connected, screen: state.screen, diagnostic: state.diagnostic,
      eventCounts: events, friendCount: friends.size, gameCount: games.size }, null, 2);
  }
  function mount() {
    if (!host.document || !host.document.body || panel) return;
    var doc = host.document;
    panel = doc.createElement('section'); panel.id = 'warcraft-follow-panel';
    panel.style.cssText = 'position:fixed;top:12px;left:12px;z-index:2147483000;width:320px;padding:14px;background:#141b25;color:#f4f0df;border:1px solid #c4a56a;border-radius:8px;font:14px/1.4 Arial,sans-serif;box-shadow:0 4px 24px #0009;pointer-events:auto';
    panel.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center"><strong>Follow friend · prototype</strong><button data-id="collapse" type="button">Hide</button></div>' +
      '<div data-id="body"><label style="display:block;margin-top:10px">Friend’s full BattleTag<input data-id="target" placeholder="Friend#1234" maxlength="46" style="display:block;box-sizing:border-box;width:100%;padding:7px;margin:4px 0 9px;color:#111;background:#fff"></label>' +
      '<label><input data-id="diagnostic" type="checkbox" checked> Diagnostics only (do not join)</label>' +
      '<div style="display:flex;gap:7px;margin-top:10px"><button data-id="toggle" type="button">Enable Follow</button><button data-id="retry" type="button">Retry</button><button data-id="export" type="button">Diagnostics</button></div>' +
      '<p data-id="status" role="status" style="margin:10px 0 4px;overflow-wrap:anywhere"></p><small data-id="details"></small>' +
      '<textarea data-id="report" readonly aria-label="Diagnostics report" style="display:none;width:100%;height:140px;margin-top:8px;box-sizing:border-box;color:#111;background:#fff"></textarea></div>';
    var el = function (id) { return panel.querySelector('[data-id="' + id + '"]'); };
    el('target').value = state.target;
    function apply(enabled) {
      try { configure({ target: el('target').value, diagnostic: el('diagnostic').checked, enabled: enabled }); }
      catch (err) { note(err.message); }
    }
    el('toggle').onclick = function () { apply(!state.enabled); };
    el('diagnostic').onchange = function () { apply(state.enabled); };
    el('target').onchange = function () { apply(false); };
    el('retry').onclick = function () {
      if (state.pending) { note('A join is still pending. Please wait.'); return; }
      attempts.clear(); targetSeenAt = gamesSeenAt = -Infinity;
      lastFriendsRequest = lastGamesRequest = -Infinity; tick();
      note('Waiting for fresh friend and lobby information.');
    };
    el('collapse').onclick = function () {
      var hidden = el('body').style.display === 'none';
      el('body').style.display = hidden ? '' : 'none'; el('collapse').textContent = hidden ? 'Hide' : 'Show';
    };
    el('export').onclick = function () {
      el('report').value = exportDiagnostics(); el('report').style.display = 'block'; el('report').select();
    };
    observers.push(function (s) {
      el('status').textContent = s.status;
      el('toggle').textContent = s.enabled ? 'Disable Follow' : 'Enable Follow';
      el('details').textContent = (s.connected ? 'Connected' : 'Disconnected') + ' · ' +
        (s.screen || 'screen unknown') + ' · ' + s.friends.length + ' friends · ' + s.gameCount + ' lobbies';
    });
    doc.body.appendChild(panel); notify();
  }
  var api = { configure: configure, receive: receive, tick: tick, snapshot: snapshot,
    exportDiagnostics: exportDiagnostics, attach: attach, mount: mount,
    setConnected: function (value) { state.connected = Boolean(value); if (!value) resetSession(); },
    stop: function () { state.enabled = false; if (timer) host.clearInterval(timer); notify(); } };
  if (!options.manual) {
    try { state.target = host.localStorage.getItem('warcraft-follow-target') || ''; } catch (_) { /* optional */ }
    installHook();
    timer = host.setInterval(function () {
      if (Array.isArray(host.sockets)) host.sockets.forEach(attach);
      mount(); tick();
    }, 1000);
    mount();
  }
  return api;
});
